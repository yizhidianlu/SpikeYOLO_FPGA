// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsa_detect_head.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSa_detect_head_CfgInitialize(XSa_detect_head *InstancePtr, XSa_detect_head_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSa_detect_head_Start(XSa_detect_head *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSa_detect_head_IsDone(XSa_detect_head *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSa_detect_head_IsIdle(XSa_detect_head *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSa_detect_head_IsReady(XSa_detect_head *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSa_detect_head_EnableAutoRestart(XSa_detect_head *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSa_detect_head_DisableAutoRestart(XSa_detect_head *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_AP_CTRL, 0);
}

void XSa_detect_head_Set_N(XSa_detect_head *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_N_DATA, Data);
}

u32 XSa_detect_head_Get_N(XSa_detect_head *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_N_DATA);
    return Data;
}

void XSa_detect_head_Set_C(XSa_detect_head *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_C_DATA, Data);
}

u32 XSa_detect_head_Get_C(XSa_detect_head *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_C_DATA);
    return Data;
}

void XSa_detect_head_Set_H(XSa_detect_head *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_H_DATA, Data);
}

u32 XSa_detect_head_Get_H(XSa_detect_head *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_H_DATA);
    return Data;
}

void XSa_detect_head_Set_W(XSa_detect_head *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_W_DATA, Data);
}

u32 XSa_detect_head_Get_W(XSa_detect_head *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_W_DATA);
    return Data;
}

void XSa_detect_head_Set_x_in(XSa_detect_head *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_DETECT_HEAD_CONTROL_R_ADDR_X_IN_DATA, (u32)(Data));
    XSa_detect_head_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_DETECT_HEAD_CONTROL_R_ADDR_X_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_detect_head_Get_x_in(XSa_detect_head *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_DETECT_HEAD_CONTROL_R_ADDR_X_IN_DATA);
    Data += (u64)XSa_detect_head_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_DETECT_HEAD_CONTROL_R_ADDR_X_IN_DATA + 4) << 32;
    return Data;
}

void XSa_detect_head_Set_y_out(XSa_detect_head *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_DETECT_HEAD_CONTROL_R_ADDR_Y_OUT_DATA, (u32)(Data));
    XSa_detect_head_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_DETECT_HEAD_CONTROL_R_ADDR_Y_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_detect_head_Get_y_out(XSa_detect_head *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_detect_head_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_DETECT_HEAD_CONTROL_R_ADDR_Y_OUT_DATA);
    Data += (u64)XSa_detect_head_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_DETECT_HEAD_CONTROL_R_ADDR_Y_OUT_DATA + 4) << 32;
    return Data;
}

void XSa_detect_head_InterruptGlobalEnable(XSa_detect_head *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_GIE, 1);
}

void XSa_detect_head_InterruptGlobalDisable(XSa_detect_head *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_GIE, 0);
}

void XSa_detect_head_InterruptEnable(XSa_detect_head *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_IER);
    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_IER, Register | Mask);
}

void XSa_detect_head_InterruptDisable(XSa_detect_head *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_IER);
    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSa_detect_head_InterruptClear(XSa_detect_head *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_detect_head_WriteReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_ISR, Mask);
}

u32 XSa_detect_head_InterruptGetEnabled(XSa_detect_head *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_IER);
}

u32 XSa_detect_head_InterruptGetStatus(XSa_detect_head *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_detect_head_ReadReg(InstancePtr->Control_BaseAddress, XSA_DETECT_HEAD_CONTROL_ADDR_ISR);
}

