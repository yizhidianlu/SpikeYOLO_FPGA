// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSA_DETECT_HEAD_H
#define XSA_DETECT_HEAD_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsa_detect_head_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XSa_detect_head_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XSa_detect_head;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSa_detect_head_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSa_detect_head_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSa_detect_head_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSa_detect_head_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XSa_detect_head_Initialize(XSa_detect_head *InstancePtr, UINTPTR BaseAddress);
XSa_detect_head_Config* XSa_detect_head_LookupConfig(UINTPTR BaseAddress);
#else
int XSa_detect_head_Initialize(XSa_detect_head *InstancePtr, u16 DeviceId);
XSa_detect_head_Config* XSa_detect_head_LookupConfig(u16 DeviceId);
#endif
int XSa_detect_head_CfgInitialize(XSa_detect_head *InstancePtr, XSa_detect_head_Config *ConfigPtr);
#else
int XSa_detect_head_Initialize(XSa_detect_head *InstancePtr, const char* InstanceName);
int XSa_detect_head_Release(XSa_detect_head *InstancePtr);
#endif

void XSa_detect_head_Start(XSa_detect_head *InstancePtr);
u32 XSa_detect_head_IsDone(XSa_detect_head *InstancePtr);
u32 XSa_detect_head_IsIdle(XSa_detect_head *InstancePtr);
u32 XSa_detect_head_IsReady(XSa_detect_head *InstancePtr);
void XSa_detect_head_EnableAutoRestart(XSa_detect_head *InstancePtr);
void XSa_detect_head_DisableAutoRestart(XSa_detect_head *InstancePtr);

void XSa_detect_head_Set_N(XSa_detect_head *InstancePtr, u32 Data);
u32 XSa_detect_head_Get_N(XSa_detect_head *InstancePtr);
void XSa_detect_head_Set_C(XSa_detect_head *InstancePtr, u32 Data);
u32 XSa_detect_head_Get_C(XSa_detect_head *InstancePtr);
void XSa_detect_head_Set_H(XSa_detect_head *InstancePtr, u32 Data);
u32 XSa_detect_head_Get_H(XSa_detect_head *InstancePtr);
void XSa_detect_head_Set_W(XSa_detect_head *InstancePtr, u32 Data);
u32 XSa_detect_head_Get_W(XSa_detect_head *InstancePtr);
void XSa_detect_head_Set_x_in(XSa_detect_head *InstancePtr, u64 Data);
u64 XSa_detect_head_Get_x_in(XSa_detect_head *InstancePtr);
void XSa_detect_head_Set_y_out(XSa_detect_head *InstancePtr, u64 Data);
u64 XSa_detect_head_Get_y_out(XSa_detect_head *InstancePtr);

void XSa_detect_head_InterruptGlobalEnable(XSa_detect_head *InstancePtr);
void XSa_detect_head_InterruptGlobalDisable(XSa_detect_head *InstancePtr);
void XSa_detect_head_InterruptEnable(XSa_detect_head *InstancePtr, u32 Mask);
void XSa_detect_head_InterruptDisable(XSa_detect_head *InstancePtr, u32 Mask);
void XSa_detect_head_InterruptClear(XSa_detect_head *InstancePtr, u32 Mask);
u32 XSa_detect_head_InterruptGetEnabled(XSa_detect_head *InstancePtr);
u32 XSa_detect_head_InterruptGetStatus(XSa_detect_head *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
