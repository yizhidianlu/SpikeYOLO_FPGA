// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of N
//        bit 31~0 - N[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of C
//        bit 31~0 - C[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of H
//        bit 31~0 - H[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of W
//        bit 31~0 - W[31:0] (Read/Write)
// 0x2c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_DETECT_HEAD_CONTROL_ADDR_AP_CTRL 0x00
#define XSA_DETECT_HEAD_CONTROL_ADDR_GIE     0x04
#define XSA_DETECT_HEAD_CONTROL_ADDR_IER     0x08
#define XSA_DETECT_HEAD_CONTROL_ADDR_ISR     0x0c
#define XSA_DETECT_HEAD_CONTROL_ADDR_N_DATA  0x10
#define XSA_DETECT_HEAD_CONTROL_BITS_N_DATA  32
#define XSA_DETECT_HEAD_CONTROL_ADDR_C_DATA  0x18
#define XSA_DETECT_HEAD_CONTROL_BITS_C_DATA  32
#define XSA_DETECT_HEAD_CONTROL_ADDR_H_DATA  0x20
#define XSA_DETECT_HEAD_CONTROL_BITS_H_DATA  32
#define XSA_DETECT_HEAD_CONTROL_ADDR_W_DATA  0x28
#define XSA_DETECT_HEAD_CONTROL_BITS_W_DATA  32

// control_r
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of x_in
//        bit 31~0 - x_in[31:0] (Read/Write)
// 0x14 : Data signal of x_in
//        bit 31~0 - x_in[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of y_out
//        bit 31~0 - y_out[31:0] (Read/Write)
// 0x20 : Data signal of y_out
//        bit 31~0 - y_out[63:32] (Read/Write)
// 0x24 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_DETECT_HEAD_CONTROL_R_ADDR_X_IN_DATA  0x10
#define XSA_DETECT_HEAD_CONTROL_R_BITS_X_IN_DATA  64
#define XSA_DETECT_HEAD_CONTROL_R_ADDR_Y_OUT_DATA 0x1c
#define XSA_DETECT_HEAD_CONTROL_R_BITS_Y_OUT_DATA 64

