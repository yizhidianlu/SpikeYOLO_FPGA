// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xsa_detect_head.h"

extern XSa_detect_head_Config XSa_detect_head_ConfigTable[];

#ifdef SDT
XSa_detect_head_Config *XSa_detect_head_LookupConfig(UINTPTR BaseAddress) {
	XSa_detect_head_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XSa_detect_head_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XSa_detect_head_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XSa_detect_head_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSa_detect_head_Initialize(XSa_detect_head *InstancePtr, UINTPTR BaseAddress) {
	XSa_detect_head_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSa_detect_head_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSa_detect_head_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XSa_detect_head_Config *XSa_detect_head_LookupConfig(u16 DeviceId) {
	XSa_detect_head_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSA_DETECT_HEAD_NUM_INSTANCES; Index++) {
		if (XSa_detect_head_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSa_detect_head_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSa_detect_head_Initialize(XSa_detect_head *InstancePtr, u16 DeviceId) {
	XSa_detect_head_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSa_detect_head_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSa_detect_head_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

