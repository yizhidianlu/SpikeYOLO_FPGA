// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsa_ms_all_conv_block.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSa_ms_all_conv_block_CfgInitialize(XSa_ms_all_conv_block *InstancePtr, XSa_ms_all_conv_block_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSa_ms_all_conv_block_Start(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSa_ms_all_conv_block_IsDone(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSa_ms_all_conv_block_IsIdle(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSa_ms_all_conv_block_IsReady(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSa_ms_all_conv_block_EnableAutoRestart(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSa_ms_all_conv_block_DisableAutoRestart(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL, 0);
}

void XSa_ms_all_conv_block_InterruptGlobalEnable(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_GIE, 1);
}

void XSa_ms_all_conv_block_InterruptGlobalDisable(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_GIE, 0);
}

void XSa_ms_all_conv_block_InterruptEnable(XSa_ms_all_conv_block *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER);
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER, Register | Mask);
}

void XSa_ms_all_conv_block_InterruptDisable(XSa_ms_all_conv_block *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER);
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSa_ms_all_conv_block_InterruptClear(XSa_ms_all_conv_block *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_ISR, Mask);
}

u32 XSa_ms_all_conv_block_InterruptGetEnabled(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER);
}

u32 XSa_ms_all_conv_block_InterruptGetStatus(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_ISR);
}

