// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsa_ms_all_conv_block.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSa_ms_all_conv_block_CfgInitialize(XSa_ms_all_conv_block *InstancePtr, XSa_ms_all_conv_block_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSa_ms_all_conv_block_Start(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSa_ms_all_conv_block_IsDone(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSa_ms_all_conv_block_IsIdle(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSa_ms_all_conv_block_IsReady(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSa_ms_all_conv_block_EnableAutoRestart(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSa_ms_all_conv_block_DisableAutoRestart(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL, 0);
}

void XSa_ms_all_conv_block_Set_T(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_T_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_T(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_T_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_C(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_C_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_C(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_C_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_C_exp(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_C_EXP_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_C_exp(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_C_EXP_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_C_mid(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_C_MID_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_C_mid(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_C_MID_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_H(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_H_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_H(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_H_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_W(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_W_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_W(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_W_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_K_dw2(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_DW2_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_K_dw2(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_DW2_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_K_dw4(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_DW4_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_K_dw4(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_DW4_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_pad_dw2(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_DW2_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_pad_dw2(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_DW2_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_pad_dw4(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_DW4_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_pad_dw4(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_DW4_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_K_c1(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_C1_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_K_c1(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_C1_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_pad_c1(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_C1_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_pad_c1(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_C1_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_K_c2(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_C2_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_K_c2(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_C2_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_pad_c2(XSa_ms_all_conv_block *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_C2_DATA, Data);
}

u32 XSa_ms_all_conv_block_Get_pad_c2(XSa_ms_all_conv_block *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_C2_DATA);
    return Data;
}

void XSa_ms_all_conv_block_Set_x_in(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_X_IN_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_X_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_x_in(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_X_IN_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_X_IN_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_y(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_Y_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_Y_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_y(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_Y_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_Y_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_w0(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W0_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W0_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_w0(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W0_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W0_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_b0(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B0_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B0_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_b0(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B0_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B0_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_s0(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S0_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S0_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_s0(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S0_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S0_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_w1(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W1_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W1_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_w1(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W1_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W1_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_b1(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B1_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B1_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_b1(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B1_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B1_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_s1(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S1_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S1_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_s1(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S1_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S1_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_w2(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W2_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W2_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_w2(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W2_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W2_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_b2(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B2_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B2_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_b2(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B2_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B2_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_s2(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S2_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S2_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_s2(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S2_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S2_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_w3(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W3_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W3_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_w3(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W3_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W3_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_b3(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B3_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B3_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_b3(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B3_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B3_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_s3(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S3_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S3_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_s3(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S3_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S3_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_c1_w(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_W_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_W_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_c1_w(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_W_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_W_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_c1_b(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_B_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_B_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_c1_b(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_B_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_B_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_c1_s(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_S_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_S_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_c1_s(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_S_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_S_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_c2_w(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_W_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_W_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_c2_w(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_W_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_W_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_c2_b(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_B_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_B_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_c2_b(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_B_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_B_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_c2_s(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_S_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_S_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_c2_s(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_S_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_S_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_r_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_R_BUF_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_R_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_r_buf(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_R_BUF_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_R_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_sep_y_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_Y_BUF_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_Y_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_sep_y_buf(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_Y_BUF_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_Y_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_ping_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PING_BUF_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PING_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_ping_buf(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PING_BUF_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PING_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_pong_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PONG_BUF_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PONG_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_pong_buf(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PONG_BUF_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PONG_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_spike_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SPIKE_BUF_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SPIKE_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_spike_buf(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SPIKE_BUF_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SPIKE_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_Set_tmp_acc(XSa_ms_all_conv_block *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_TMP_ACC_DATA, (u32)(Data));
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_TMP_ACC_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_all_conv_block_Get_tmp_acc(XSa_ms_all_conv_block *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_TMP_ACC_DATA);
    Data += (u64)XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_TMP_ACC_DATA + 4) << 32;
    return Data;
}

void XSa_ms_all_conv_block_InterruptGlobalEnable(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_GIE, 1);
}

void XSa_ms_all_conv_block_InterruptGlobalDisable(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_GIE, 0);
}

void XSa_ms_all_conv_block_InterruptEnable(XSa_ms_all_conv_block *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER);
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER, Register | Mask);
}

void XSa_ms_all_conv_block_InterruptDisable(XSa_ms_all_conv_block *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER);
    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSa_ms_all_conv_block_InterruptClear(XSa_ms_all_conv_block *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_all_conv_block_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_ISR, Mask);
}

u32 XSa_ms_all_conv_block_InterruptGetEnabled(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER);
}

u32 XSa_ms_all_conv_block_InterruptGetStatus(XSa_ms_all_conv_block *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_ms_all_conv_block_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_ISR);
}

