// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSA_MS_ALL_CONV_BLOCK_H
#define XSA_MS_ALL_CONV_BLOCK_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsa_ms_all_conv_block_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XSa_ms_all_conv_block_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XSa_ms_all_conv_block;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSa_ms_all_conv_block_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSa_ms_all_conv_block_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSa_ms_all_conv_block_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSa_ms_all_conv_block_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XSa_ms_all_conv_block_Initialize(XSa_ms_all_conv_block *InstancePtr, UINTPTR BaseAddress);
XSa_ms_all_conv_block_Config* XSa_ms_all_conv_block_LookupConfig(UINTPTR BaseAddress);
#else
int XSa_ms_all_conv_block_Initialize(XSa_ms_all_conv_block *InstancePtr, u16 DeviceId);
XSa_ms_all_conv_block_Config* XSa_ms_all_conv_block_LookupConfig(u16 DeviceId);
#endif
int XSa_ms_all_conv_block_CfgInitialize(XSa_ms_all_conv_block *InstancePtr, XSa_ms_all_conv_block_Config *ConfigPtr);
#else
int XSa_ms_all_conv_block_Initialize(XSa_ms_all_conv_block *InstancePtr, const char* InstanceName);
int XSa_ms_all_conv_block_Release(XSa_ms_all_conv_block *InstancePtr);
#endif

void XSa_ms_all_conv_block_Start(XSa_ms_all_conv_block *InstancePtr);
u32 XSa_ms_all_conv_block_IsDone(XSa_ms_all_conv_block *InstancePtr);
u32 XSa_ms_all_conv_block_IsIdle(XSa_ms_all_conv_block *InstancePtr);
u32 XSa_ms_all_conv_block_IsReady(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_EnableAutoRestart(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_DisableAutoRestart(XSa_ms_all_conv_block *InstancePtr);

void XSa_ms_all_conv_block_Set_T(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_T(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_C(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_C(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_C_exp(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_C_exp(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_C_mid(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_C_mid(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_H(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_H(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_W(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_W(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_K_dw2(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_K_dw2(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_K_dw4(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_K_dw4(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_pad_dw2(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_pad_dw2(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_pad_dw4(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_pad_dw4(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_K_c1(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_K_c1(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_pad_c1(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_pad_c1(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_K_c2(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_K_c2(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_pad_c2(XSa_ms_all_conv_block *InstancePtr, u32 Data);
u32 XSa_ms_all_conv_block_Get_pad_c2(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_x_in(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_x_in(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_y(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_y(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_w0(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_w0(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_b0(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_b0(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_s0(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_s0(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_w1(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_w1(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_b1(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_b1(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_s1(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_s1(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_w2(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_w2(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_b2(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_b2(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_s2(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_s2(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_w3(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_w3(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_b3(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_b3(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_s3(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_s3(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_c1_w(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_c1_w(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_c1_b(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_c1_b(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_c1_s(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_c1_s(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_c2_w(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_c2_w(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_c2_b(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_c2_b(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_c2_s(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_c2_s(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_r_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_r_buf(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_sep_y_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_sep_y_buf(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_ping_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_ping_buf(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_pong_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_pong_buf(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_spike_buf(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_spike_buf(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_Set_tmp_acc(XSa_ms_all_conv_block *InstancePtr, u64 Data);
u64 XSa_ms_all_conv_block_Get_tmp_acc(XSa_ms_all_conv_block *InstancePtr);

void XSa_ms_all_conv_block_InterruptGlobalEnable(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_InterruptGlobalDisable(XSa_ms_all_conv_block *InstancePtr);
void XSa_ms_all_conv_block_InterruptEnable(XSa_ms_all_conv_block *InstancePtr, u32 Mask);
void XSa_ms_all_conv_block_InterruptDisable(XSa_ms_all_conv_block *InstancePtr, u32 Mask);
void XSa_ms_all_conv_block_InterruptClear(XSa_ms_all_conv_block *InstancePtr, u32 Mask);
u32 XSa_ms_all_conv_block_InterruptGetEnabled(XSa_ms_all_conv_block *InstancePtr);
u32 XSa_ms_all_conv_block_InterruptGetStatus(XSa_ms_all_conv_block *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
