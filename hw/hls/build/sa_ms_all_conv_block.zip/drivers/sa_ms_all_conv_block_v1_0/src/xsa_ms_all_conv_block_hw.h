// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of T
//        bit 31~0 - T[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of C
//        bit 31~0 - C[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of C_exp
//        bit 31~0 - C_exp[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of C_mid
//        bit 31~0 - C_mid[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of H
//        bit 31~0 - H[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of W
//        bit 31~0 - W[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of K_dw2
//        bit 31~0 - K_dw2[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of K_dw4
//        bit 31~0 - K_dw4[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of pad_dw2
//        bit 31~0 - pad_dw2[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of pad_dw4
//        bit 31~0 - pad_dw4[31:0] (Read/Write)
// 0x5c : reserved
// 0x60 : Data signal of K_c1
//        bit 31~0 - K_c1[31:0] (Read/Write)
// 0x64 : reserved
// 0x68 : Data signal of pad_c1
//        bit 31~0 - pad_c1[31:0] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of K_c2
//        bit 31~0 - K_c2[31:0] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of pad_c2
//        bit 31~0 - pad_c2[31:0] (Read/Write)
// 0x7c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_AP_CTRL      0x00
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_GIE          0x04
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_IER          0x08
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_ISR          0x0c
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_T_DATA       0x10
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_T_DATA       32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_C_DATA       0x18
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_C_DATA       32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_C_EXP_DATA   0x20
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_C_EXP_DATA   32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_C_MID_DATA   0x28
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_C_MID_DATA   32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_H_DATA       0x30
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_H_DATA       32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_W_DATA       0x38
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_W_DATA       32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_DW2_DATA   0x40
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_K_DW2_DATA   32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_DW4_DATA   0x48
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_K_DW4_DATA   32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_DW2_DATA 0x50
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_PAD_DW2_DATA 32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_DW4_DATA 0x58
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_PAD_DW4_DATA 32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_C1_DATA    0x60
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_K_C1_DATA    32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_C1_DATA  0x68
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_PAD_C1_DATA  32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_K_C2_DATA    0x70
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_K_C2_DATA    32
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_ADDR_PAD_C2_DATA  0x78
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_BITS_PAD_C2_DATA  32

// control_r
// 0x000 : reserved
// 0x004 : reserved
// 0x008 : reserved
// 0x00c : reserved
// 0x010 : Data signal of x_in
//         bit 31~0 - x_in[31:0] (Read/Write)
// 0x014 : Data signal of x_in
//         bit 31~0 - x_in[63:32] (Read/Write)
// 0x018 : reserved
// 0x01c : Data signal of y
//         bit 31~0 - y[31:0] (Read/Write)
// 0x020 : Data signal of y
//         bit 31~0 - y[63:32] (Read/Write)
// 0x024 : reserved
// 0x028 : Data signal of sep_w0
//         bit 31~0 - sep_w0[31:0] (Read/Write)
// 0x02c : Data signal of sep_w0
//         bit 31~0 - sep_w0[63:32] (Read/Write)
// 0x030 : reserved
// 0x034 : Data signal of sep_b0
//         bit 31~0 - sep_b0[31:0] (Read/Write)
// 0x038 : Data signal of sep_b0
//         bit 31~0 - sep_b0[63:32] (Read/Write)
// 0x03c : reserved
// 0x040 : Data signal of sep_s0
//         bit 31~0 - sep_s0[31:0] (Read/Write)
// 0x044 : Data signal of sep_s0
//         bit 31~0 - sep_s0[63:32] (Read/Write)
// 0x048 : reserved
// 0x04c : Data signal of sep_w1
//         bit 31~0 - sep_w1[31:0] (Read/Write)
// 0x050 : Data signal of sep_w1
//         bit 31~0 - sep_w1[63:32] (Read/Write)
// 0x054 : reserved
// 0x058 : Data signal of sep_b1
//         bit 31~0 - sep_b1[31:0] (Read/Write)
// 0x05c : Data signal of sep_b1
//         bit 31~0 - sep_b1[63:32] (Read/Write)
// 0x060 : reserved
// 0x064 : Data signal of sep_s1
//         bit 31~0 - sep_s1[31:0] (Read/Write)
// 0x068 : Data signal of sep_s1
//         bit 31~0 - sep_s1[63:32] (Read/Write)
// 0x06c : reserved
// 0x070 : Data signal of sep_w2
//         bit 31~0 - sep_w2[31:0] (Read/Write)
// 0x074 : Data signal of sep_w2
//         bit 31~0 - sep_w2[63:32] (Read/Write)
// 0x078 : reserved
// 0x07c : Data signal of sep_b2
//         bit 31~0 - sep_b2[31:0] (Read/Write)
// 0x080 : Data signal of sep_b2
//         bit 31~0 - sep_b2[63:32] (Read/Write)
// 0x084 : reserved
// 0x088 : Data signal of sep_s2
//         bit 31~0 - sep_s2[31:0] (Read/Write)
// 0x08c : Data signal of sep_s2
//         bit 31~0 - sep_s2[63:32] (Read/Write)
// 0x090 : reserved
// 0x094 : Data signal of sep_w3
//         bit 31~0 - sep_w3[31:0] (Read/Write)
// 0x098 : Data signal of sep_w3
//         bit 31~0 - sep_w3[63:32] (Read/Write)
// 0x09c : reserved
// 0x0a0 : Data signal of sep_b3
//         bit 31~0 - sep_b3[31:0] (Read/Write)
// 0x0a4 : Data signal of sep_b3
//         bit 31~0 - sep_b3[63:32] (Read/Write)
// 0x0a8 : reserved
// 0x0ac : Data signal of sep_s3
//         bit 31~0 - sep_s3[31:0] (Read/Write)
// 0x0b0 : Data signal of sep_s3
//         bit 31~0 - sep_s3[63:32] (Read/Write)
// 0x0b4 : reserved
// 0x0b8 : Data signal of c1_w
//         bit 31~0 - c1_w[31:0] (Read/Write)
// 0x0bc : Data signal of c1_w
//         bit 31~0 - c1_w[63:32] (Read/Write)
// 0x0c0 : reserved
// 0x0c4 : Data signal of c1_b
//         bit 31~0 - c1_b[31:0] (Read/Write)
// 0x0c8 : Data signal of c1_b
//         bit 31~0 - c1_b[63:32] (Read/Write)
// 0x0cc : reserved
// 0x0d0 : Data signal of c1_s
//         bit 31~0 - c1_s[31:0] (Read/Write)
// 0x0d4 : Data signal of c1_s
//         bit 31~0 - c1_s[63:32] (Read/Write)
// 0x0d8 : reserved
// 0x0dc : Data signal of c2_w
//         bit 31~0 - c2_w[31:0] (Read/Write)
// 0x0e0 : Data signal of c2_w
//         bit 31~0 - c2_w[63:32] (Read/Write)
// 0x0e4 : reserved
// 0x0e8 : Data signal of c2_b
//         bit 31~0 - c2_b[31:0] (Read/Write)
// 0x0ec : Data signal of c2_b
//         bit 31~0 - c2_b[63:32] (Read/Write)
// 0x0f0 : reserved
// 0x0f4 : Data signal of c2_s
//         bit 31~0 - c2_s[31:0] (Read/Write)
// 0x0f8 : Data signal of c2_s
//         bit 31~0 - c2_s[63:32] (Read/Write)
// 0x0fc : reserved
// 0x100 : Data signal of r_buf
//         bit 31~0 - r_buf[31:0] (Read/Write)
// 0x104 : Data signal of r_buf
//         bit 31~0 - r_buf[63:32] (Read/Write)
// 0x108 : reserved
// 0x10c : Data signal of sep_y_buf
//         bit 31~0 - sep_y_buf[31:0] (Read/Write)
// 0x110 : Data signal of sep_y_buf
//         bit 31~0 - sep_y_buf[63:32] (Read/Write)
// 0x114 : reserved
// 0x118 : Data signal of ping_buf
//         bit 31~0 - ping_buf[31:0] (Read/Write)
// 0x11c : Data signal of ping_buf
//         bit 31~0 - ping_buf[63:32] (Read/Write)
// 0x120 : reserved
// 0x124 : Data signal of pong_buf
//         bit 31~0 - pong_buf[31:0] (Read/Write)
// 0x128 : Data signal of pong_buf
//         bit 31~0 - pong_buf[63:32] (Read/Write)
// 0x12c : reserved
// 0x130 : Data signal of spike_buf
//         bit 31~0 - spike_buf[31:0] (Read/Write)
// 0x134 : Data signal of spike_buf
//         bit 31~0 - spike_buf[63:32] (Read/Write)
// 0x138 : reserved
// 0x13c : Data signal of tmp_acc
//         bit 31~0 - tmp_acc[31:0] (Read/Write)
// 0x140 : Data signal of tmp_acc
//         bit 31~0 - tmp_acc[63:32] (Read/Write)
// 0x144 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_X_IN_DATA      0x010
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_X_IN_DATA      64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_Y_DATA         0x01c
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_Y_DATA         64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W0_DATA    0x028
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_W0_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B0_DATA    0x034
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_B0_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S0_DATA    0x040
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_S0_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W1_DATA    0x04c
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_W1_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B1_DATA    0x058
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_B1_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S1_DATA    0x064
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_S1_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W2_DATA    0x070
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_W2_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B2_DATA    0x07c
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_B2_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S2_DATA    0x088
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_S2_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_W3_DATA    0x094
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_W3_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_B3_DATA    0x0a0
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_B3_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_S3_DATA    0x0ac
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_S3_DATA    64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_W_DATA      0x0b8
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_C1_W_DATA      64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_B_DATA      0x0c4
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_C1_B_DATA      64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C1_S_DATA      0x0d0
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_C1_S_DATA      64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_W_DATA      0x0dc
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_C2_W_DATA      64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_B_DATA      0x0e8
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_C2_B_DATA      64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_C2_S_DATA      0x0f4
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_C2_S_DATA      64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_R_BUF_DATA     0x100
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_R_BUF_DATA     64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SEP_Y_BUF_DATA 0x10c
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SEP_Y_BUF_DATA 64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PING_BUF_DATA  0x118
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_PING_BUF_DATA  64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_PONG_BUF_DATA  0x124
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_PONG_BUF_DATA  64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_SPIKE_BUF_DATA 0x130
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_SPIKE_BUF_DATA 64
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_ADDR_TMP_ACC_DATA   0x13c
#define XSA_MS_ALL_CONV_BLOCK_CONTROL_R_BITS_TMP_ACC_DATA   64

