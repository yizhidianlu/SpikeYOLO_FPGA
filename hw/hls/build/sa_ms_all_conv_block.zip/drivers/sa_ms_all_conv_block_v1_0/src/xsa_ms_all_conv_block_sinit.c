// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xsa_ms_all_conv_block.h"

extern XSa_ms_all_conv_block_Config XSa_ms_all_conv_block_ConfigTable[];

#ifdef SDT
XSa_ms_all_conv_block_Config *XSa_ms_all_conv_block_LookupConfig(UINTPTR BaseAddress) {
	XSa_ms_all_conv_block_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XSa_ms_all_conv_block_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XSa_ms_all_conv_block_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XSa_ms_all_conv_block_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSa_ms_all_conv_block_Initialize(XSa_ms_all_conv_block *InstancePtr, UINTPTR BaseAddress) {
	XSa_ms_all_conv_block_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSa_ms_all_conv_block_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSa_ms_all_conv_block_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XSa_ms_all_conv_block_Config *XSa_ms_all_conv_block_LookupConfig(u16 DeviceId) {
	XSa_ms_all_conv_block_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSA_MS_ALL_CONV_BLOCK_NUM_INSTANCES; Index++) {
		if (XSa_ms_all_conv_block_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSa_ms_all_conv_block_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSa_ms_all_conv_block_Initialize(XSa_ms_all_conv_block *InstancePtr, u16 DeviceId) {
	XSa_ms_all_conv_block_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSa_ms_all_conv_block_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSa_ms_all_conv_block_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

