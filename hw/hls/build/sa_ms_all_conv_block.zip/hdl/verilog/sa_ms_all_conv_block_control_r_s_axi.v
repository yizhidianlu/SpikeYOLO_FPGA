// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module sa_ms_all_conv_block_control_r_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 9,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire [63:0]                   x_in,
    output wire [63:0]                   y,
    output wire [63:0]                   sep_w0,
    output wire [63:0]                   sep_b0,
    output wire [63:0]                   sep_s0,
    output wire [63:0]                   sep_w1,
    output wire [63:0]                   sep_b1,
    output wire [63:0]                   sep_s1,
    output wire [63:0]                   sep_w2,
    output wire [63:0]                   sep_b2,
    output wire [63:0]                   sep_s2,
    output wire [63:0]                   sep_w3,
    output wire [63:0]                   sep_b3,
    output wire [63:0]                   sep_s3,
    output wire [63:0]                   c1_w,
    output wire [63:0]                   c1_b,
    output wire [63:0]                   c1_s,
    output wire [63:0]                   c2_w,
    output wire [63:0]                   c2_b,
    output wire [63:0]                   c2_s,
    output wire [63:0]                   r_buf,
    output wire [63:0]                   sep_y_buf,
    output wire [63:0]                   ping_buf,
    output wire [63:0]                   pong_buf,
    output wire [63:0]                   spike_buf,
    output wire [63:0]                   tmp_acc
);
//------------------------Address Info-------------------
// Protocol Used: ap_ctrl_none
//
// 0x000 : reserved
// 0x004 : reserved
// 0x008 : reserved
// 0x00c : reserved
// 0x010 : Data signal of x_in
//         bit 31~0 - x_in[31:0] (Read/Write)
// 0x014 : Data signal of x_in
//         bit 31~0 - x_in[63:32] (Read/Write)
// 0x018 : reserved
// 0x01c : Data signal of y
//         bit 31~0 - y[31:0] (Read/Write)
// 0x020 : Data signal of y
//         bit 31~0 - y[63:32] (Read/Write)
// 0x024 : reserved
// 0x028 : Data signal of sep_w0
//         bit 31~0 - sep_w0[31:0] (Read/Write)
// 0x02c : Data signal of sep_w0
//         bit 31~0 - sep_w0[63:32] (Read/Write)
// 0x030 : reserved
// 0x034 : Data signal of sep_b0
//         bit 31~0 - sep_b0[31:0] (Read/Write)
// 0x038 : Data signal of sep_b0
//         bit 31~0 - sep_b0[63:32] (Read/Write)
// 0x03c : reserved
// 0x040 : Data signal of sep_s0
//         bit 31~0 - sep_s0[31:0] (Read/Write)
// 0x044 : Data signal of sep_s0
//         bit 31~0 - sep_s0[63:32] (Read/Write)
// 0x048 : reserved
// 0x04c : Data signal of sep_w1
//         bit 31~0 - sep_w1[31:0] (Read/Write)
// 0x050 : Data signal of sep_w1
//         bit 31~0 - sep_w1[63:32] (Read/Write)
// 0x054 : reserved
// 0x058 : Data signal of sep_b1
//         bit 31~0 - sep_b1[31:0] (Read/Write)
// 0x05c : Data signal of sep_b1
//         bit 31~0 - sep_b1[63:32] (Read/Write)
// 0x060 : reserved
// 0x064 : Data signal of sep_s1
//         bit 31~0 - sep_s1[31:0] (Read/Write)
// 0x068 : Data signal of sep_s1
//         bit 31~0 - sep_s1[63:32] (Read/Write)
// 0x06c : reserved
// 0x070 : Data signal of sep_w2
//         bit 31~0 - sep_w2[31:0] (Read/Write)
// 0x074 : Data signal of sep_w2
//         bit 31~0 - sep_w2[63:32] (Read/Write)
// 0x078 : reserved
// 0x07c : Data signal of sep_b2
//         bit 31~0 - sep_b2[31:0] (Read/Write)
// 0x080 : Data signal of sep_b2
//         bit 31~0 - sep_b2[63:32] (Read/Write)
// 0x084 : reserved
// 0x088 : Data signal of sep_s2
//         bit 31~0 - sep_s2[31:0] (Read/Write)
// 0x08c : Data signal of sep_s2
//         bit 31~0 - sep_s2[63:32] (Read/Write)
// 0x090 : reserved
// 0x094 : Data signal of sep_w3
//         bit 31~0 - sep_w3[31:0] (Read/Write)
// 0x098 : Data signal of sep_w3
//         bit 31~0 - sep_w3[63:32] (Read/Write)
// 0x09c : reserved
// 0x0a0 : Data signal of sep_b3
//         bit 31~0 - sep_b3[31:0] (Read/Write)
// 0x0a4 : Data signal of sep_b3
//         bit 31~0 - sep_b3[63:32] (Read/Write)
// 0x0a8 : reserved
// 0x0ac : Data signal of sep_s3
//         bit 31~0 - sep_s3[31:0] (Read/Write)
// 0x0b0 : Data signal of sep_s3
//         bit 31~0 - sep_s3[63:32] (Read/Write)
// 0x0b4 : reserved
// 0x0b8 : Data signal of c1_w
//         bit 31~0 - c1_w[31:0] (Read/Write)
// 0x0bc : Data signal of c1_w
//         bit 31~0 - c1_w[63:32] (Read/Write)
// 0x0c0 : reserved
// 0x0c4 : Data signal of c1_b
//         bit 31~0 - c1_b[31:0] (Read/Write)
// 0x0c8 : Data signal of c1_b
//         bit 31~0 - c1_b[63:32] (Read/Write)
// 0x0cc : reserved
// 0x0d0 : Data signal of c1_s
//         bit 31~0 - c1_s[31:0] (Read/Write)
// 0x0d4 : Data signal of c1_s
//         bit 31~0 - c1_s[63:32] (Read/Write)
// 0x0d8 : reserved
// 0x0dc : Data signal of c2_w
//         bit 31~0 - c2_w[31:0] (Read/Write)
// 0x0e0 : Data signal of c2_w
//         bit 31~0 - c2_w[63:32] (Read/Write)
// 0x0e4 : reserved
// 0x0e8 : Data signal of c2_b
//         bit 31~0 - c2_b[31:0] (Read/Write)
// 0x0ec : Data signal of c2_b
//         bit 31~0 - c2_b[63:32] (Read/Write)
// 0x0f0 : reserved
// 0x0f4 : Data signal of c2_s
//         bit 31~0 - c2_s[31:0] (Read/Write)
// 0x0f8 : Data signal of c2_s
//         bit 31~0 - c2_s[63:32] (Read/Write)
// 0x0fc : reserved
// 0x100 : Data signal of r_buf
//         bit 31~0 - r_buf[31:0] (Read/Write)
// 0x104 : Data signal of r_buf
//         bit 31~0 - r_buf[63:32] (Read/Write)
// 0x108 : reserved
// 0x10c : Data signal of sep_y_buf
//         bit 31~0 - sep_y_buf[31:0] (Read/Write)
// 0x110 : Data signal of sep_y_buf
//         bit 31~0 - sep_y_buf[63:32] (Read/Write)
// 0x114 : reserved
// 0x118 : Data signal of ping_buf
//         bit 31~0 - ping_buf[31:0] (Read/Write)
// 0x11c : Data signal of ping_buf
//         bit 31~0 - ping_buf[63:32] (Read/Write)
// 0x120 : reserved
// 0x124 : Data signal of pong_buf
//         bit 31~0 - pong_buf[31:0] (Read/Write)
// 0x128 : Data signal of pong_buf
//         bit 31~0 - pong_buf[63:32] (Read/Write)
// 0x12c : reserved
// 0x130 : Data signal of spike_buf
//         bit 31~0 - spike_buf[31:0] (Read/Write)
// 0x134 : Data signal of spike_buf
//         bit 31~0 - spike_buf[63:32] (Read/Write)
// 0x138 : reserved
// 0x13c : Data signal of tmp_acc
//         bit 31~0 - tmp_acc[31:0] (Read/Write)
// 0x140 : Data signal of tmp_acc
//         bit 31~0 - tmp_acc[63:32] (Read/Write)
// 0x144 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_X_IN_DATA_0      = 9'h010,
    ADDR_X_IN_DATA_1      = 9'h014,
    ADDR_X_IN_CTRL        = 9'h018,
    ADDR_Y_DATA_0         = 9'h01c,
    ADDR_Y_DATA_1         = 9'h020,
    ADDR_Y_CTRL           = 9'h024,
    ADDR_SEP_W0_DATA_0    = 9'h028,
    ADDR_SEP_W0_DATA_1    = 9'h02c,
    ADDR_SEP_W0_CTRL      = 9'h030,
    ADDR_SEP_B0_DATA_0    = 9'h034,
    ADDR_SEP_B0_DATA_1    = 9'h038,
    ADDR_SEP_B0_CTRL      = 9'h03c,
    ADDR_SEP_S0_DATA_0    = 9'h040,
    ADDR_SEP_S0_DATA_1    = 9'h044,
    ADDR_SEP_S0_CTRL      = 9'h048,
    ADDR_SEP_W1_DATA_0    = 9'h04c,
    ADDR_SEP_W1_DATA_1    = 9'h050,
    ADDR_SEP_W1_CTRL      = 9'h054,
    ADDR_SEP_B1_DATA_0    = 9'h058,
    ADDR_SEP_B1_DATA_1    = 9'h05c,
    ADDR_SEP_B1_CTRL      = 9'h060,
    ADDR_SEP_S1_DATA_0    = 9'h064,
    ADDR_SEP_S1_DATA_1    = 9'h068,
    ADDR_SEP_S1_CTRL      = 9'h06c,
    ADDR_SEP_W2_DATA_0    = 9'h070,
    ADDR_SEP_W2_DATA_1    = 9'h074,
    ADDR_SEP_W2_CTRL      = 9'h078,
    ADDR_SEP_B2_DATA_0    = 9'h07c,
    ADDR_SEP_B2_DATA_1    = 9'h080,
    ADDR_SEP_B2_CTRL      = 9'h084,
    ADDR_SEP_S2_DATA_0    = 9'h088,
    ADDR_SEP_S2_DATA_1    = 9'h08c,
    ADDR_SEP_S2_CTRL      = 9'h090,
    ADDR_SEP_W3_DATA_0    = 9'h094,
    ADDR_SEP_W3_DATA_1    = 9'h098,
    ADDR_SEP_W3_CTRL      = 9'h09c,
    ADDR_SEP_B3_DATA_0    = 9'h0a0,
    ADDR_SEP_B3_DATA_1    = 9'h0a4,
    ADDR_SEP_B3_CTRL      = 9'h0a8,
    ADDR_SEP_S3_DATA_0    = 9'h0ac,
    ADDR_SEP_S3_DATA_1    = 9'h0b0,
    ADDR_SEP_S3_CTRL      = 9'h0b4,
    ADDR_C1_W_DATA_0      = 9'h0b8,
    ADDR_C1_W_DATA_1      = 9'h0bc,
    ADDR_C1_W_CTRL        = 9'h0c0,
    ADDR_C1_B_DATA_0      = 9'h0c4,
    ADDR_C1_B_DATA_1      = 9'h0c8,
    ADDR_C1_B_CTRL        = 9'h0cc,
    ADDR_C1_S_DATA_0      = 9'h0d0,
    ADDR_C1_S_DATA_1      = 9'h0d4,
    ADDR_C1_S_CTRL        = 9'h0d8,
    ADDR_C2_W_DATA_0      = 9'h0dc,
    ADDR_C2_W_DATA_1      = 9'h0e0,
    ADDR_C2_W_CTRL        = 9'h0e4,
    ADDR_C2_B_DATA_0      = 9'h0e8,
    ADDR_C2_B_DATA_1      = 9'h0ec,
    ADDR_C2_B_CTRL        = 9'h0f0,
    ADDR_C2_S_DATA_0      = 9'h0f4,
    ADDR_C2_S_DATA_1      = 9'h0f8,
    ADDR_C2_S_CTRL        = 9'h0fc,
    ADDR_R_BUF_DATA_0     = 9'h100,
    ADDR_R_BUF_DATA_1     = 9'h104,
    ADDR_R_BUF_CTRL       = 9'h108,
    ADDR_SEP_Y_BUF_DATA_0 = 9'h10c,
    ADDR_SEP_Y_BUF_DATA_1 = 9'h110,
    ADDR_SEP_Y_BUF_CTRL   = 9'h114,
    ADDR_PING_BUF_DATA_0  = 9'h118,
    ADDR_PING_BUF_DATA_1  = 9'h11c,
    ADDR_PING_BUF_CTRL    = 9'h120,
    ADDR_PONG_BUF_DATA_0  = 9'h124,
    ADDR_PONG_BUF_DATA_1  = 9'h128,
    ADDR_PONG_BUF_CTRL    = 9'h12c,
    ADDR_SPIKE_BUF_DATA_0 = 9'h130,
    ADDR_SPIKE_BUF_DATA_1 = 9'h134,
    ADDR_SPIKE_BUF_CTRL   = 9'h138,
    ADDR_TMP_ACC_DATA_0   = 9'h13c,
    ADDR_TMP_ACC_DATA_1   = 9'h140,
    ADDR_TMP_ACC_CTRL     = 9'h144,
    WRIDLE                = 2'd0,
    WRDATA                = 2'd1,
    WRRESP                = 2'd2,
    WRRESET               = 2'd3,
    RDIDLE                = 2'd0,
    RDDATA                = 2'd1,
    RDRESET               = 2'd2,
    ADDR_BITS                = 9;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg  [63:0]                   int_x_in = 'b0;
    reg  [63:0]                   int_y = 'b0;
    reg  [63:0]                   int_sep_w0 = 'b0;
    reg  [63:0]                   int_sep_b0 = 'b0;
    reg  [63:0]                   int_sep_s0 = 'b0;
    reg  [63:0]                   int_sep_w1 = 'b0;
    reg  [63:0]                   int_sep_b1 = 'b0;
    reg  [63:0]                   int_sep_s1 = 'b0;
    reg  [63:0]                   int_sep_w2 = 'b0;
    reg  [63:0]                   int_sep_b2 = 'b0;
    reg  [63:0]                   int_sep_s2 = 'b0;
    reg  [63:0]                   int_sep_w3 = 'b0;
    reg  [63:0]                   int_sep_b3 = 'b0;
    reg  [63:0]                   int_sep_s3 = 'b0;
    reg  [63:0]                   int_c1_w = 'b0;
    reg  [63:0]                   int_c1_b = 'b0;
    reg  [63:0]                   int_c1_s = 'b0;
    reg  [63:0]                   int_c2_w = 'b0;
    reg  [63:0]                   int_c2_b = 'b0;
    reg  [63:0]                   int_c2_s = 'b0;
    reg  [63:0]                   int_r_buf = 'b0;
    reg  [63:0]                   int_sep_y_buf = 'b0;
    reg  [63:0]                   int_ping_buf = 'b0;
    reg  [63:0]                   int_pong_buf = 'b0;
    reg  [63:0]                   int_spike_buf = 'b0;
    reg  [63:0]                   int_tmp_acc = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BRESP   = 2'b00;  // OKAY
assign BVALID  = (wstate == WRRESP);
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= {AWADDR[ADDR_BITS-1:2], {2{1'b0}}};
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_X_IN_DATA_0: begin
                    rdata <= int_x_in[31:0];
                end
                ADDR_X_IN_DATA_1: begin
                    rdata <= int_x_in[63:32];
                end
                ADDR_Y_DATA_0: begin
                    rdata <= int_y[31:0];
                end
                ADDR_Y_DATA_1: begin
                    rdata <= int_y[63:32];
                end
                ADDR_SEP_W0_DATA_0: begin
                    rdata <= int_sep_w0[31:0];
                end
                ADDR_SEP_W0_DATA_1: begin
                    rdata <= int_sep_w0[63:32];
                end
                ADDR_SEP_B0_DATA_0: begin
                    rdata <= int_sep_b0[31:0];
                end
                ADDR_SEP_B0_DATA_1: begin
                    rdata <= int_sep_b0[63:32];
                end
                ADDR_SEP_S0_DATA_0: begin
                    rdata <= int_sep_s0[31:0];
                end
                ADDR_SEP_S0_DATA_1: begin
                    rdata <= int_sep_s0[63:32];
                end
                ADDR_SEP_W1_DATA_0: begin
                    rdata <= int_sep_w1[31:0];
                end
                ADDR_SEP_W1_DATA_1: begin
                    rdata <= int_sep_w1[63:32];
                end
                ADDR_SEP_B1_DATA_0: begin
                    rdata <= int_sep_b1[31:0];
                end
                ADDR_SEP_B1_DATA_1: begin
                    rdata <= int_sep_b1[63:32];
                end
                ADDR_SEP_S1_DATA_0: begin
                    rdata <= int_sep_s1[31:0];
                end
                ADDR_SEP_S1_DATA_1: begin
                    rdata <= int_sep_s1[63:32];
                end
                ADDR_SEP_W2_DATA_0: begin
                    rdata <= int_sep_w2[31:0];
                end
                ADDR_SEP_W2_DATA_1: begin
                    rdata <= int_sep_w2[63:32];
                end
                ADDR_SEP_B2_DATA_0: begin
                    rdata <= int_sep_b2[31:0];
                end
                ADDR_SEP_B2_DATA_1: begin
                    rdata <= int_sep_b2[63:32];
                end
                ADDR_SEP_S2_DATA_0: begin
                    rdata <= int_sep_s2[31:0];
                end
                ADDR_SEP_S2_DATA_1: begin
                    rdata <= int_sep_s2[63:32];
                end
                ADDR_SEP_W3_DATA_0: begin
                    rdata <= int_sep_w3[31:0];
                end
                ADDR_SEP_W3_DATA_1: begin
                    rdata <= int_sep_w3[63:32];
                end
                ADDR_SEP_B3_DATA_0: begin
                    rdata <= int_sep_b3[31:0];
                end
                ADDR_SEP_B3_DATA_1: begin
                    rdata <= int_sep_b3[63:32];
                end
                ADDR_SEP_S3_DATA_0: begin
                    rdata <= int_sep_s3[31:0];
                end
                ADDR_SEP_S3_DATA_1: begin
                    rdata <= int_sep_s3[63:32];
                end
                ADDR_C1_W_DATA_0: begin
                    rdata <= int_c1_w[31:0];
                end
                ADDR_C1_W_DATA_1: begin
                    rdata <= int_c1_w[63:32];
                end
                ADDR_C1_B_DATA_0: begin
                    rdata <= int_c1_b[31:0];
                end
                ADDR_C1_B_DATA_1: begin
                    rdata <= int_c1_b[63:32];
                end
                ADDR_C1_S_DATA_0: begin
                    rdata <= int_c1_s[31:0];
                end
                ADDR_C1_S_DATA_1: begin
                    rdata <= int_c1_s[63:32];
                end
                ADDR_C2_W_DATA_0: begin
                    rdata <= int_c2_w[31:0];
                end
                ADDR_C2_W_DATA_1: begin
                    rdata <= int_c2_w[63:32];
                end
                ADDR_C2_B_DATA_0: begin
                    rdata <= int_c2_b[31:0];
                end
                ADDR_C2_B_DATA_1: begin
                    rdata <= int_c2_b[63:32];
                end
                ADDR_C2_S_DATA_0: begin
                    rdata <= int_c2_s[31:0];
                end
                ADDR_C2_S_DATA_1: begin
                    rdata <= int_c2_s[63:32];
                end
                ADDR_R_BUF_DATA_0: begin
                    rdata <= int_r_buf[31:0];
                end
                ADDR_R_BUF_DATA_1: begin
                    rdata <= int_r_buf[63:32];
                end
                ADDR_SEP_Y_BUF_DATA_0: begin
                    rdata <= int_sep_y_buf[31:0];
                end
                ADDR_SEP_Y_BUF_DATA_1: begin
                    rdata <= int_sep_y_buf[63:32];
                end
                ADDR_PING_BUF_DATA_0: begin
                    rdata <= int_ping_buf[31:0];
                end
                ADDR_PING_BUF_DATA_1: begin
                    rdata <= int_ping_buf[63:32];
                end
                ADDR_PONG_BUF_DATA_0: begin
                    rdata <= int_pong_buf[31:0];
                end
                ADDR_PONG_BUF_DATA_1: begin
                    rdata <= int_pong_buf[63:32];
                end
                ADDR_SPIKE_BUF_DATA_0: begin
                    rdata <= int_spike_buf[31:0];
                end
                ADDR_SPIKE_BUF_DATA_1: begin
                    rdata <= int_spike_buf[63:32];
                end
                ADDR_TMP_ACC_DATA_0: begin
                    rdata <= int_tmp_acc[31:0];
                end
                ADDR_TMP_ACC_DATA_1: begin
                    rdata <= int_tmp_acc[63:32];
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign x_in      = int_x_in;
assign y         = int_y;
assign sep_w0    = int_sep_w0;
assign sep_b0    = int_sep_b0;
assign sep_s0    = int_sep_s0;
assign sep_w1    = int_sep_w1;
assign sep_b1    = int_sep_b1;
assign sep_s1    = int_sep_s1;
assign sep_w2    = int_sep_w2;
assign sep_b2    = int_sep_b2;
assign sep_s2    = int_sep_s2;
assign sep_w3    = int_sep_w3;
assign sep_b3    = int_sep_b3;
assign sep_s3    = int_sep_s3;
assign c1_w      = int_c1_w;
assign c1_b      = int_c1_b;
assign c1_s      = int_c1_s;
assign c2_w      = int_c2_w;
assign c2_b      = int_c2_b;
assign c2_s      = int_c2_s;
assign r_buf     = int_r_buf;
assign sep_y_buf = int_sep_y_buf;
assign ping_buf  = int_ping_buf;
assign pong_buf  = int_pong_buf;
assign spike_buf = int_spike_buf;
assign tmp_acc   = int_tmp_acc;
// int_x_in[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_x_in[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_X_IN_DATA_0)
            int_x_in[31:0] <= (WDATA[31:0] & wmask) | (int_x_in[31:0] & ~wmask);
    end
end

// int_x_in[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_x_in[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_X_IN_DATA_1)
            int_x_in[63:32] <= (WDATA[31:0] & wmask) | (int_x_in[63:32] & ~wmask);
    end
end

// int_y[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_y[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_Y_DATA_0)
            int_y[31:0] <= (WDATA[31:0] & wmask) | (int_y[31:0] & ~wmask);
    end
end

// int_y[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_y[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_Y_DATA_1)
            int_y[63:32] <= (WDATA[31:0] & wmask) | (int_y[63:32] & ~wmask);
    end
end

// int_sep_w0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_w0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_W0_DATA_0)
            int_sep_w0[31:0] <= (WDATA[31:0] & wmask) | (int_sep_w0[31:0] & ~wmask);
    end
end

// int_sep_w0[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_w0[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_W0_DATA_1)
            int_sep_w0[63:32] <= (WDATA[31:0] & wmask) | (int_sep_w0[63:32] & ~wmask);
    end
end

// int_sep_b0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_b0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_B0_DATA_0)
            int_sep_b0[31:0] <= (WDATA[31:0] & wmask) | (int_sep_b0[31:0] & ~wmask);
    end
end

// int_sep_b0[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_b0[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_B0_DATA_1)
            int_sep_b0[63:32] <= (WDATA[31:0] & wmask) | (int_sep_b0[63:32] & ~wmask);
    end
end

// int_sep_s0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_s0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_S0_DATA_0)
            int_sep_s0[31:0] <= (WDATA[31:0] & wmask) | (int_sep_s0[31:0] & ~wmask);
    end
end

// int_sep_s0[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_s0[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_S0_DATA_1)
            int_sep_s0[63:32] <= (WDATA[31:0] & wmask) | (int_sep_s0[63:32] & ~wmask);
    end
end

// int_sep_w1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_w1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_W1_DATA_0)
            int_sep_w1[31:0] <= (WDATA[31:0] & wmask) | (int_sep_w1[31:0] & ~wmask);
    end
end

// int_sep_w1[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_w1[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_W1_DATA_1)
            int_sep_w1[63:32] <= (WDATA[31:0] & wmask) | (int_sep_w1[63:32] & ~wmask);
    end
end

// int_sep_b1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_b1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_B1_DATA_0)
            int_sep_b1[31:0] <= (WDATA[31:0] & wmask) | (int_sep_b1[31:0] & ~wmask);
    end
end

// int_sep_b1[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_b1[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_B1_DATA_1)
            int_sep_b1[63:32] <= (WDATA[31:0] & wmask) | (int_sep_b1[63:32] & ~wmask);
    end
end

// int_sep_s1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_s1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_S1_DATA_0)
            int_sep_s1[31:0] <= (WDATA[31:0] & wmask) | (int_sep_s1[31:0] & ~wmask);
    end
end

// int_sep_s1[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_s1[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_S1_DATA_1)
            int_sep_s1[63:32] <= (WDATA[31:0] & wmask) | (int_sep_s1[63:32] & ~wmask);
    end
end

// int_sep_w2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_w2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_W2_DATA_0)
            int_sep_w2[31:0] <= (WDATA[31:0] & wmask) | (int_sep_w2[31:0] & ~wmask);
    end
end

// int_sep_w2[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_w2[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_W2_DATA_1)
            int_sep_w2[63:32] <= (WDATA[31:0] & wmask) | (int_sep_w2[63:32] & ~wmask);
    end
end

// int_sep_b2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_b2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_B2_DATA_0)
            int_sep_b2[31:0] <= (WDATA[31:0] & wmask) | (int_sep_b2[31:0] & ~wmask);
    end
end

// int_sep_b2[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_b2[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_B2_DATA_1)
            int_sep_b2[63:32] <= (WDATA[31:0] & wmask) | (int_sep_b2[63:32] & ~wmask);
    end
end

// int_sep_s2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_s2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_S2_DATA_0)
            int_sep_s2[31:0] <= (WDATA[31:0] & wmask) | (int_sep_s2[31:0] & ~wmask);
    end
end

// int_sep_s2[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_s2[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_S2_DATA_1)
            int_sep_s2[63:32] <= (WDATA[31:0] & wmask) | (int_sep_s2[63:32] & ~wmask);
    end
end

// int_sep_w3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_w3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_W3_DATA_0)
            int_sep_w3[31:0] <= (WDATA[31:0] & wmask) | (int_sep_w3[31:0] & ~wmask);
    end
end

// int_sep_w3[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_w3[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_W3_DATA_1)
            int_sep_w3[63:32] <= (WDATA[31:0] & wmask) | (int_sep_w3[63:32] & ~wmask);
    end
end

// int_sep_b3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_b3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_B3_DATA_0)
            int_sep_b3[31:0] <= (WDATA[31:0] & wmask) | (int_sep_b3[31:0] & ~wmask);
    end
end

// int_sep_b3[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_b3[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_B3_DATA_1)
            int_sep_b3[63:32] <= (WDATA[31:0] & wmask) | (int_sep_b3[63:32] & ~wmask);
    end
end

// int_sep_s3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_s3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_S3_DATA_0)
            int_sep_s3[31:0] <= (WDATA[31:0] & wmask) | (int_sep_s3[31:0] & ~wmask);
    end
end

// int_sep_s3[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_s3[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_S3_DATA_1)
            int_sep_s3[63:32] <= (WDATA[31:0] & wmask) | (int_sep_s3[63:32] & ~wmask);
    end
end

// int_c1_w[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_c1_w[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C1_W_DATA_0)
            int_c1_w[31:0] <= (WDATA[31:0] & wmask) | (int_c1_w[31:0] & ~wmask);
    end
end

// int_c1_w[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_c1_w[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C1_W_DATA_1)
            int_c1_w[63:32] <= (WDATA[31:0] & wmask) | (int_c1_w[63:32] & ~wmask);
    end
end

// int_c1_b[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_c1_b[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C1_B_DATA_0)
            int_c1_b[31:0] <= (WDATA[31:0] & wmask) | (int_c1_b[31:0] & ~wmask);
    end
end

// int_c1_b[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_c1_b[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C1_B_DATA_1)
            int_c1_b[63:32] <= (WDATA[31:0] & wmask) | (int_c1_b[63:32] & ~wmask);
    end
end

// int_c1_s[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_c1_s[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C1_S_DATA_0)
            int_c1_s[31:0] <= (WDATA[31:0] & wmask) | (int_c1_s[31:0] & ~wmask);
    end
end

// int_c1_s[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_c1_s[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C1_S_DATA_1)
            int_c1_s[63:32] <= (WDATA[31:0] & wmask) | (int_c1_s[63:32] & ~wmask);
    end
end

// int_c2_w[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_c2_w[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C2_W_DATA_0)
            int_c2_w[31:0] <= (WDATA[31:0] & wmask) | (int_c2_w[31:0] & ~wmask);
    end
end

// int_c2_w[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_c2_w[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C2_W_DATA_1)
            int_c2_w[63:32] <= (WDATA[31:0] & wmask) | (int_c2_w[63:32] & ~wmask);
    end
end

// int_c2_b[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_c2_b[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C2_B_DATA_0)
            int_c2_b[31:0] <= (WDATA[31:0] & wmask) | (int_c2_b[31:0] & ~wmask);
    end
end

// int_c2_b[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_c2_b[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C2_B_DATA_1)
            int_c2_b[63:32] <= (WDATA[31:0] & wmask) | (int_c2_b[63:32] & ~wmask);
    end
end

// int_c2_s[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_c2_s[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C2_S_DATA_0)
            int_c2_s[31:0] <= (WDATA[31:0] & wmask) | (int_c2_s[31:0] & ~wmask);
    end
end

// int_c2_s[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_c2_s[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_C2_S_DATA_1)
            int_c2_s[63:32] <= (WDATA[31:0] & wmask) | (int_c2_s[63:32] & ~wmask);
    end
end

// int_r_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_r_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_R_BUF_DATA_0)
            int_r_buf[31:0] <= (WDATA[31:0] & wmask) | (int_r_buf[31:0] & ~wmask);
    end
end

// int_r_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_r_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_R_BUF_DATA_1)
            int_r_buf[63:32] <= (WDATA[31:0] & wmask) | (int_r_buf[63:32] & ~wmask);
    end
end

// int_sep_y_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_y_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_Y_BUF_DATA_0)
            int_sep_y_buf[31:0] <= (WDATA[31:0] & wmask) | (int_sep_y_buf[31:0] & ~wmask);
    end
end

// int_sep_y_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_sep_y_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SEP_Y_BUF_DATA_1)
            int_sep_y_buf[63:32] <= (WDATA[31:0] & wmask) | (int_sep_y_buf[63:32] & ~wmask);
    end
end

// int_ping_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_ping_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PING_BUF_DATA_0)
            int_ping_buf[31:0] <= (WDATA[31:0] & wmask) | (int_ping_buf[31:0] & ~wmask);
    end
end

// int_ping_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_ping_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PING_BUF_DATA_1)
            int_ping_buf[63:32] <= (WDATA[31:0] & wmask) | (int_ping_buf[63:32] & ~wmask);
    end
end

// int_pong_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pong_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PONG_BUF_DATA_0)
            int_pong_buf[31:0] <= (WDATA[31:0] & wmask) | (int_pong_buf[31:0] & ~wmask);
    end
end

// int_pong_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_pong_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PONG_BUF_DATA_1)
            int_pong_buf[63:32] <= (WDATA[31:0] & wmask) | (int_pong_buf[63:32] & ~wmask);
    end
end

// int_spike_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_spike_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SPIKE_BUF_DATA_0)
            int_spike_buf[31:0] <= (WDATA[31:0] & wmask) | (int_spike_buf[31:0] & ~wmask);
    end
end

// int_spike_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_spike_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SPIKE_BUF_DATA_1)
            int_spike_buf[63:32] <= (WDATA[31:0] & wmask) | (int_spike_buf[63:32] & ~wmask);
    end
end

// int_tmp_acc[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_tmp_acc[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_TMP_ACC_DATA_0)
            int_tmp_acc[31:0] <= (WDATA[31:0] & wmask) | (int_tmp_acc[31:0] & ~wmask);
    end
end

// int_tmp_acc[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_tmp_acc[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_TMP_ACC_DATA_1)
            int_tmp_acc[63:32] <= (WDATA[31:0] & wmask) | (int_tmp_acc[63:32] & ~wmask);
    end
end


//------------------------Memory logic-------------------

endmodule
