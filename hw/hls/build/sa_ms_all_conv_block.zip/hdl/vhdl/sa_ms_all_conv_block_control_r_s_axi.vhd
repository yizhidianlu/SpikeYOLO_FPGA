-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
-- Tool Version Limit: 2024.05
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- 
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity sa_ms_all_conv_block_control_r_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 9;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    x_in                  :out  STD_LOGIC_VECTOR(63 downto 0);
    y                     :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_w0                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_b0                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_s0                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_w1                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_b1                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_s1                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_w2                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_b2                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_s2                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_w3                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_b3                :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_s3                :out  STD_LOGIC_VECTOR(63 downto 0);
    c1_w                  :out  STD_LOGIC_VECTOR(63 downto 0);
    c1_b                  :out  STD_LOGIC_VECTOR(63 downto 0);
    c1_s                  :out  STD_LOGIC_VECTOR(63 downto 0);
    c2_w                  :out  STD_LOGIC_VECTOR(63 downto 0);
    c2_b                  :out  STD_LOGIC_VECTOR(63 downto 0);
    c2_s                  :out  STD_LOGIC_VECTOR(63 downto 0);
    r_buf                 :out  STD_LOGIC_VECTOR(63 downto 0);
    sep_y_buf             :out  STD_LOGIC_VECTOR(63 downto 0);
    ping_buf              :out  STD_LOGIC_VECTOR(63 downto 0);
    pong_buf              :out  STD_LOGIC_VECTOR(63 downto 0);
    spike_buf             :out  STD_LOGIC_VECTOR(63 downto 0);
    tmp_acc               :out  STD_LOGIC_VECTOR(63 downto 0)
);
end entity sa_ms_all_conv_block_control_r_s_axi;

-- ------------------------Address Info-------------------
-- Protocol Used: ap_ctrl_none
--
-- 0x000 : reserved
-- 0x004 : reserved
-- 0x008 : reserved
-- 0x00c : reserved
-- 0x010 : Data signal of x_in
--         bit 31~0 - x_in[31:0] (Read/Write)
-- 0x014 : Data signal of x_in
--         bit 31~0 - x_in[63:32] (Read/Write)
-- 0x018 : reserved
-- 0x01c : Data signal of y
--         bit 31~0 - y[31:0] (Read/Write)
-- 0x020 : Data signal of y
--         bit 31~0 - y[63:32] (Read/Write)
-- 0x024 : reserved
-- 0x028 : Data signal of sep_w0
--         bit 31~0 - sep_w0[31:0] (Read/Write)
-- 0x02c : Data signal of sep_w0
--         bit 31~0 - sep_w0[63:32] (Read/Write)
-- 0x030 : reserved
-- 0x034 : Data signal of sep_b0
--         bit 31~0 - sep_b0[31:0] (Read/Write)
-- 0x038 : Data signal of sep_b0
--         bit 31~0 - sep_b0[63:32] (Read/Write)
-- 0x03c : reserved
-- 0x040 : Data signal of sep_s0
--         bit 31~0 - sep_s0[31:0] (Read/Write)
-- 0x044 : Data signal of sep_s0
--         bit 31~0 - sep_s0[63:32] (Read/Write)
-- 0x048 : reserved
-- 0x04c : Data signal of sep_w1
--         bit 31~0 - sep_w1[31:0] (Read/Write)
-- 0x050 : Data signal of sep_w1
--         bit 31~0 - sep_w1[63:32] (Read/Write)
-- 0x054 : reserved
-- 0x058 : Data signal of sep_b1
--         bit 31~0 - sep_b1[31:0] (Read/Write)
-- 0x05c : Data signal of sep_b1
--         bit 31~0 - sep_b1[63:32] (Read/Write)
-- 0x060 : reserved
-- 0x064 : Data signal of sep_s1
--         bit 31~0 - sep_s1[31:0] (Read/Write)
-- 0x068 : Data signal of sep_s1
--         bit 31~0 - sep_s1[63:32] (Read/Write)
-- 0x06c : reserved
-- 0x070 : Data signal of sep_w2
--         bit 31~0 - sep_w2[31:0] (Read/Write)
-- 0x074 : Data signal of sep_w2
--         bit 31~0 - sep_w2[63:32] (Read/Write)
-- 0x078 : reserved
-- 0x07c : Data signal of sep_b2
--         bit 31~0 - sep_b2[31:0] (Read/Write)
-- 0x080 : Data signal of sep_b2
--         bit 31~0 - sep_b2[63:32] (Read/Write)
-- 0x084 : reserved
-- 0x088 : Data signal of sep_s2
--         bit 31~0 - sep_s2[31:0] (Read/Write)
-- 0x08c : Data signal of sep_s2
--         bit 31~0 - sep_s2[63:32] (Read/Write)
-- 0x090 : reserved
-- 0x094 : Data signal of sep_w3
--         bit 31~0 - sep_w3[31:0] (Read/Write)
-- 0x098 : Data signal of sep_w3
--         bit 31~0 - sep_w3[63:32] (Read/Write)
-- 0x09c : reserved
-- 0x0a0 : Data signal of sep_b3
--         bit 31~0 - sep_b3[31:0] (Read/Write)
-- 0x0a4 : Data signal of sep_b3
--         bit 31~0 - sep_b3[63:32] (Read/Write)
-- 0x0a8 : reserved
-- 0x0ac : Data signal of sep_s3
--         bit 31~0 - sep_s3[31:0] (Read/Write)
-- 0x0b0 : Data signal of sep_s3
--         bit 31~0 - sep_s3[63:32] (Read/Write)
-- 0x0b4 : reserved
-- 0x0b8 : Data signal of c1_w
--         bit 31~0 - c1_w[31:0] (Read/Write)
-- 0x0bc : Data signal of c1_w
--         bit 31~0 - c1_w[63:32] (Read/Write)
-- 0x0c0 : reserved
-- 0x0c4 : Data signal of c1_b
--         bit 31~0 - c1_b[31:0] (Read/Write)
-- 0x0c8 : Data signal of c1_b
--         bit 31~0 - c1_b[63:32] (Read/Write)
-- 0x0cc : reserved
-- 0x0d0 : Data signal of c1_s
--         bit 31~0 - c1_s[31:0] (Read/Write)
-- 0x0d4 : Data signal of c1_s
--         bit 31~0 - c1_s[63:32] (Read/Write)
-- 0x0d8 : reserved
-- 0x0dc : Data signal of c2_w
--         bit 31~0 - c2_w[31:0] (Read/Write)
-- 0x0e0 : Data signal of c2_w
--         bit 31~0 - c2_w[63:32] (Read/Write)
-- 0x0e4 : reserved
-- 0x0e8 : Data signal of c2_b
--         bit 31~0 - c2_b[31:0] (Read/Write)
-- 0x0ec : Data signal of c2_b
--         bit 31~0 - c2_b[63:32] (Read/Write)
-- 0x0f0 : reserved
-- 0x0f4 : Data signal of c2_s
--         bit 31~0 - c2_s[31:0] (Read/Write)
-- 0x0f8 : Data signal of c2_s
--         bit 31~0 - c2_s[63:32] (Read/Write)
-- 0x0fc : reserved
-- 0x100 : Data signal of r_buf
--         bit 31~0 - r_buf[31:0] (Read/Write)
-- 0x104 : Data signal of r_buf
--         bit 31~0 - r_buf[63:32] (Read/Write)
-- 0x108 : reserved
-- 0x10c : Data signal of sep_y_buf
--         bit 31~0 - sep_y_buf[31:0] (Read/Write)
-- 0x110 : Data signal of sep_y_buf
--         bit 31~0 - sep_y_buf[63:32] (Read/Write)
-- 0x114 : reserved
-- 0x118 : Data signal of ping_buf
--         bit 31~0 - ping_buf[31:0] (Read/Write)
-- 0x11c : Data signal of ping_buf
--         bit 31~0 - ping_buf[63:32] (Read/Write)
-- 0x120 : reserved
-- 0x124 : Data signal of pong_buf
--         bit 31~0 - pong_buf[31:0] (Read/Write)
-- 0x128 : Data signal of pong_buf
--         bit 31~0 - pong_buf[63:32] (Read/Write)
-- 0x12c : reserved
-- 0x130 : Data signal of spike_buf
--         bit 31~0 - spike_buf[31:0] (Read/Write)
-- 0x134 : Data signal of spike_buf
--         bit 31~0 - spike_buf[63:32] (Read/Write)
-- 0x138 : reserved
-- 0x13c : Data signal of tmp_acc
--         bit 31~0 - tmp_acc[31:0] (Read/Write)
-- 0x140 : Data signal of tmp_acc
--         bit 31~0 - tmp_acc[63:32] (Read/Write)
-- 0x144 : reserved
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of sa_ms_all_conv_block_control_r_s_axi is
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_X_IN_DATA_0      : INTEGER := 16#010#;
    constant ADDR_X_IN_DATA_1      : INTEGER := 16#014#;
    constant ADDR_X_IN_CTRL        : INTEGER := 16#018#;
    constant ADDR_Y_DATA_0         : INTEGER := 16#01c#;
    constant ADDR_Y_DATA_1         : INTEGER := 16#020#;
    constant ADDR_Y_CTRL           : INTEGER := 16#024#;
    constant ADDR_SEP_W0_DATA_0    : INTEGER := 16#028#;
    constant ADDR_SEP_W0_DATA_1    : INTEGER := 16#02c#;
    constant ADDR_SEP_W0_CTRL      : INTEGER := 16#030#;
    constant ADDR_SEP_B0_DATA_0    : INTEGER := 16#034#;
    constant ADDR_SEP_B0_DATA_1    : INTEGER := 16#038#;
    constant ADDR_SEP_B0_CTRL      : INTEGER := 16#03c#;
    constant ADDR_SEP_S0_DATA_0    : INTEGER := 16#040#;
    constant ADDR_SEP_S0_DATA_1    : INTEGER := 16#044#;
    constant ADDR_SEP_S0_CTRL      : INTEGER := 16#048#;
    constant ADDR_SEP_W1_DATA_0    : INTEGER := 16#04c#;
    constant ADDR_SEP_W1_DATA_1    : INTEGER := 16#050#;
    constant ADDR_SEP_W1_CTRL      : INTEGER := 16#054#;
    constant ADDR_SEP_B1_DATA_0    : INTEGER := 16#058#;
    constant ADDR_SEP_B1_DATA_1    : INTEGER := 16#05c#;
    constant ADDR_SEP_B1_CTRL      : INTEGER := 16#060#;
    constant ADDR_SEP_S1_DATA_0    : INTEGER := 16#064#;
    constant ADDR_SEP_S1_DATA_1    : INTEGER := 16#068#;
    constant ADDR_SEP_S1_CTRL      : INTEGER := 16#06c#;
    constant ADDR_SEP_W2_DATA_0    : INTEGER := 16#070#;
    constant ADDR_SEP_W2_DATA_1    : INTEGER := 16#074#;
    constant ADDR_SEP_W2_CTRL      : INTEGER := 16#078#;
    constant ADDR_SEP_B2_DATA_0    : INTEGER := 16#07c#;
    constant ADDR_SEP_B2_DATA_1    : INTEGER := 16#080#;
    constant ADDR_SEP_B2_CTRL      : INTEGER := 16#084#;
    constant ADDR_SEP_S2_DATA_0    : INTEGER := 16#088#;
    constant ADDR_SEP_S2_DATA_1    : INTEGER := 16#08c#;
    constant ADDR_SEP_S2_CTRL      : INTEGER := 16#090#;
    constant ADDR_SEP_W3_DATA_0    : INTEGER := 16#094#;
    constant ADDR_SEP_W3_DATA_1    : INTEGER := 16#098#;
    constant ADDR_SEP_W3_CTRL      : INTEGER := 16#09c#;
    constant ADDR_SEP_B3_DATA_0    : INTEGER := 16#0a0#;
    constant ADDR_SEP_B3_DATA_1    : INTEGER := 16#0a4#;
    constant ADDR_SEP_B3_CTRL      : INTEGER := 16#0a8#;
    constant ADDR_SEP_S3_DATA_0    : INTEGER := 16#0ac#;
    constant ADDR_SEP_S3_DATA_1    : INTEGER := 16#0b0#;
    constant ADDR_SEP_S3_CTRL      : INTEGER := 16#0b4#;
    constant ADDR_C1_W_DATA_0      : INTEGER := 16#0b8#;
    constant ADDR_C1_W_DATA_1      : INTEGER := 16#0bc#;
    constant ADDR_C1_W_CTRL        : INTEGER := 16#0c0#;
    constant ADDR_C1_B_DATA_0      : INTEGER := 16#0c4#;
    constant ADDR_C1_B_DATA_1      : INTEGER := 16#0c8#;
    constant ADDR_C1_B_CTRL        : INTEGER := 16#0cc#;
    constant ADDR_C1_S_DATA_0      : INTEGER := 16#0d0#;
    constant ADDR_C1_S_DATA_1      : INTEGER := 16#0d4#;
    constant ADDR_C1_S_CTRL        : INTEGER := 16#0d8#;
    constant ADDR_C2_W_DATA_0      : INTEGER := 16#0dc#;
    constant ADDR_C2_W_DATA_1      : INTEGER := 16#0e0#;
    constant ADDR_C2_W_CTRL        : INTEGER := 16#0e4#;
    constant ADDR_C2_B_DATA_0      : INTEGER := 16#0e8#;
    constant ADDR_C2_B_DATA_1      : INTEGER := 16#0ec#;
    constant ADDR_C2_B_CTRL        : INTEGER := 16#0f0#;
    constant ADDR_C2_S_DATA_0      : INTEGER := 16#0f4#;
    constant ADDR_C2_S_DATA_1      : INTEGER := 16#0f8#;
    constant ADDR_C2_S_CTRL        : INTEGER := 16#0fc#;
    constant ADDR_R_BUF_DATA_0     : INTEGER := 16#100#;
    constant ADDR_R_BUF_DATA_1     : INTEGER := 16#104#;
    constant ADDR_R_BUF_CTRL       : INTEGER := 16#108#;
    constant ADDR_SEP_Y_BUF_DATA_0 : INTEGER := 16#10c#;
    constant ADDR_SEP_Y_BUF_DATA_1 : INTEGER := 16#110#;
    constant ADDR_SEP_Y_BUF_CTRL   : INTEGER := 16#114#;
    constant ADDR_PING_BUF_DATA_0  : INTEGER := 16#118#;
    constant ADDR_PING_BUF_DATA_1  : INTEGER := 16#11c#;
    constant ADDR_PING_BUF_CTRL    : INTEGER := 16#120#;
    constant ADDR_PONG_BUF_DATA_0  : INTEGER := 16#124#;
    constant ADDR_PONG_BUF_DATA_1  : INTEGER := 16#128#;
    constant ADDR_PONG_BUF_CTRL    : INTEGER := 16#12c#;
    constant ADDR_SPIKE_BUF_DATA_0 : INTEGER := 16#130#;
    constant ADDR_SPIKE_BUF_DATA_1 : INTEGER := 16#134#;
    constant ADDR_SPIKE_BUF_CTRL   : INTEGER := 16#138#;
    constant ADDR_TMP_ACC_DATA_0   : INTEGER := 16#13c#;
    constant ADDR_TMP_ACC_DATA_1   : INTEGER := 16#140#;
    constant ADDR_TMP_ACC_CTRL     : INTEGER := 16#144#;
    constant ADDR_BITS         : INTEGER := 9;

    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    -- internal registers
    signal int_x_in            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_y               : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_w0          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_b0          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_s0          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_w1          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_b1          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_s1          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_w2          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_b2          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_s2          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_w3          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_b3          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_s3          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_c1_w            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_c1_b            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_c1_s            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_c2_w            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_c2_b            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_c2_s            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_r_buf           : UNSIGNED(63 downto 0) := (others => '0');
    signal int_sep_y_buf       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_ping_buf        : UNSIGNED(63 downto 0) := (others => '0');
    signal int_pong_buf        : UNSIGNED(63 downto 0) := (others => '0');
    signal int_spike_buf       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_tmp_acc         : UNSIGNED(63 downto 0) := (others => '0');


begin
-- ----------------------- Instantiation------------------


-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata else '0';
    WREADY    <=  WREADY_t;
    BRESP     <=  "00";  -- OKAY
    BVALID    <=  '1' when wstate = wrresp else '0';
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, WVALID, BREADY)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (WVALID = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 2) & (1 downto 0 => '0'));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    rdata_data <= (others => '0');
                    case (TO_INTEGER(raddr)) is
                    when ADDR_X_IN_DATA_0 =>
                        rdata_data <= RESIZE(int_x_in(31 downto 0), 32);
                    when ADDR_X_IN_DATA_1 =>
                        rdata_data <= RESIZE(int_x_in(63 downto 32), 32);
                    when ADDR_Y_DATA_0 =>
                        rdata_data <= RESIZE(int_y(31 downto 0), 32);
                    when ADDR_Y_DATA_1 =>
                        rdata_data <= RESIZE(int_y(63 downto 32), 32);
                    when ADDR_SEP_W0_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_w0(31 downto 0), 32);
                    when ADDR_SEP_W0_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_w0(63 downto 32), 32);
                    when ADDR_SEP_B0_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_b0(31 downto 0), 32);
                    when ADDR_SEP_B0_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_b0(63 downto 32), 32);
                    when ADDR_SEP_S0_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_s0(31 downto 0), 32);
                    when ADDR_SEP_S0_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_s0(63 downto 32), 32);
                    when ADDR_SEP_W1_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_w1(31 downto 0), 32);
                    when ADDR_SEP_W1_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_w1(63 downto 32), 32);
                    when ADDR_SEP_B1_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_b1(31 downto 0), 32);
                    when ADDR_SEP_B1_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_b1(63 downto 32), 32);
                    when ADDR_SEP_S1_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_s1(31 downto 0), 32);
                    when ADDR_SEP_S1_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_s1(63 downto 32), 32);
                    when ADDR_SEP_W2_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_w2(31 downto 0), 32);
                    when ADDR_SEP_W2_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_w2(63 downto 32), 32);
                    when ADDR_SEP_B2_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_b2(31 downto 0), 32);
                    when ADDR_SEP_B2_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_b2(63 downto 32), 32);
                    when ADDR_SEP_S2_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_s2(31 downto 0), 32);
                    when ADDR_SEP_S2_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_s2(63 downto 32), 32);
                    when ADDR_SEP_W3_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_w3(31 downto 0), 32);
                    when ADDR_SEP_W3_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_w3(63 downto 32), 32);
                    when ADDR_SEP_B3_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_b3(31 downto 0), 32);
                    when ADDR_SEP_B3_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_b3(63 downto 32), 32);
                    when ADDR_SEP_S3_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_s3(31 downto 0), 32);
                    when ADDR_SEP_S3_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_s3(63 downto 32), 32);
                    when ADDR_C1_W_DATA_0 =>
                        rdata_data <= RESIZE(int_c1_w(31 downto 0), 32);
                    when ADDR_C1_W_DATA_1 =>
                        rdata_data <= RESIZE(int_c1_w(63 downto 32), 32);
                    when ADDR_C1_B_DATA_0 =>
                        rdata_data <= RESIZE(int_c1_b(31 downto 0), 32);
                    when ADDR_C1_B_DATA_1 =>
                        rdata_data <= RESIZE(int_c1_b(63 downto 32), 32);
                    when ADDR_C1_S_DATA_0 =>
                        rdata_data <= RESIZE(int_c1_s(31 downto 0), 32);
                    when ADDR_C1_S_DATA_1 =>
                        rdata_data <= RESIZE(int_c1_s(63 downto 32), 32);
                    when ADDR_C2_W_DATA_0 =>
                        rdata_data <= RESIZE(int_c2_w(31 downto 0), 32);
                    when ADDR_C2_W_DATA_1 =>
                        rdata_data <= RESIZE(int_c2_w(63 downto 32), 32);
                    when ADDR_C2_B_DATA_0 =>
                        rdata_data <= RESIZE(int_c2_b(31 downto 0), 32);
                    when ADDR_C2_B_DATA_1 =>
                        rdata_data <= RESIZE(int_c2_b(63 downto 32), 32);
                    when ADDR_C2_S_DATA_0 =>
                        rdata_data <= RESIZE(int_c2_s(31 downto 0), 32);
                    when ADDR_C2_S_DATA_1 =>
                        rdata_data <= RESIZE(int_c2_s(63 downto 32), 32);
                    when ADDR_R_BUF_DATA_0 =>
                        rdata_data <= RESIZE(int_r_buf(31 downto 0), 32);
                    when ADDR_R_BUF_DATA_1 =>
                        rdata_data <= RESIZE(int_r_buf(63 downto 32), 32);
                    when ADDR_SEP_Y_BUF_DATA_0 =>
                        rdata_data <= RESIZE(int_sep_y_buf(31 downto 0), 32);
                    when ADDR_SEP_Y_BUF_DATA_1 =>
                        rdata_data <= RESIZE(int_sep_y_buf(63 downto 32), 32);
                    when ADDR_PING_BUF_DATA_0 =>
                        rdata_data <= RESIZE(int_ping_buf(31 downto 0), 32);
                    when ADDR_PING_BUF_DATA_1 =>
                        rdata_data <= RESIZE(int_ping_buf(63 downto 32), 32);
                    when ADDR_PONG_BUF_DATA_0 =>
                        rdata_data <= RESIZE(int_pong_buf(31 downto 0), 32);
                    when ADDR_PONG_BUF_DATA_1 =>
                        rdata_data <= RESIZE(int_pong_buf(63 downto 32), 32);
                    when ADDR_SPIKE_BUF_DATA_0 =>
                        rdata_data <= RESIZE(int_spike_buf(31 downto 0), 32);
                    when ADDR_SPIKE_BUF_DATA_1 =>
                        rdata_data <= RESIZE(int_spike_buf(63 downto 32), 32);
                    when ADDR_TMP_ACC_DATA_0 =>
                        rdata_data <= RESIZE(int_tmp_acc(31 downto 0), 32);
                    when ADDR_TMP_ACC_DATA_1 =>
                        rdata_data <= RESIZE(int_tmp_acc(63 downto 32), 32);
                    when others =>
                        NULL;
                    end case;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    x_in                 <= STD_LOGIC_VECTOR(int_x_in);
    y                    <= STD_LOGIC_VECTOR(int_y);
    sep_w0               <= STD_LOGIC_VECTOR(int_sep_w0);
    sep_b0               <= STD_LOGIC_VECTOR(int_sep_b0);
    sep_s0               <= STD_LOGIC_VECTOR(int_sep_s0);
    sep_w1               <= STD_LOGIC_VECTOR(int_sep_w1);
    sep_b1               <= STD_LOGIC_VECTOR(int_sep_b1);
    sep_s1               <= STD_LOGIC_VECTOR(int_sep_s1);
    sep_w2               <= STD_LOGIC_VECTOR(int_sep_w2);
    sep_b2               <= STD_LOGIC_VECTOR(int_sep_b2);
    sep_s2               <= STD_LOGIC_VECTOR(int_sep_s2);
    sep_w3               <= STD_LOGIC_VECTOR(int_sep_w3);
    sep_b3               <= STD_LOGIC_VECTOR(int_sep_b3);
    sep_s3               <= STD_LOGIC_VECTOR(int_sep_s3);
    c1_w                 <= STD_LOGIC_VECTOR(int_c1_w);
    c1_b                 <= STD_LOGIC_VECTOR(int_c1_b);
    c1_s                 <= STD_LOGIC_VECTOR(int_c1_s);
    c2_w                 <= STD_LOGIC_VECTOR(int_c2_w);
    c2_b                 <= STD_LOGIC_VECTOR(int_c2_b);
    c2_s                 <= STD_LOGIC_VECTOR(int_c2_s);
    r_buf                <= STD_LOGIC_VECTOR(int_r_buf);
    sep_y_buf            <= STD_LOGIC_VECTOR(int_sep_y_buf);
    ping_buf             <= STD_LOGIC_VECTOR(int_ping_buf);
    pong_buf             <= STD_LOGIC_VECTOR(int_pong_buf);
    spike_buf            <= STD_LOGIC_VECTOR(int_spike_buf);
    tmp_acc              <= STD_LOGIC_VECTOR(int_tmp_acc);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_x_in(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_X_IN_DATA_0) then
                    int_x_in(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_x_in(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_x_in(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_X_IN_DATA_1) then
                    int_x_in(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_x_in(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_y(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_Y_DATA_0) then
                    int_y(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_y(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_y(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_Y_DATA_1) then
                    int_y(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_y(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_w0(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_W0_DATA_0) then
                    int_sep_w0(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_w0(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_w0(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_W0_DATA_1) then
                    int_sep_w0(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_w0(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_b0(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_B0_DATA_0) then
                    int_sep_b0(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_b0(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_b0(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_B0_DATA_1) then
                    int_sep_b0(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_b0(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_s0(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_S0_DATA_0) then
                    int_sep_s0(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_s0(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_s0(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_S0_DATA_1) then
                    int_sep_s0(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_s0(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_w1(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_W1_DATA_0) then
                    int_sep_w1(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_w1(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_w1(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_W1_DATA_1) then
                    int_sep_w1(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_w1(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_b1(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_B1_DATA_0) then
                    int_sep_b1(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_b1(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_b1(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_B1_DATA_1) then
                    int_sep_b1(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_b1(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_s1(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_S1_DATA_0) then
                    int_sep_s1(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_s1(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_s1(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_S1_DATA_1) then
                    int_sep_s1(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_s1(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_w2(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_W2_DATA_0) then
                    int_sep_w2(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_w2(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_w2(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_W2_DATA_1) then
                    int_sep_w2(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_w2(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_b2(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_B2_DATA_0) then
                    int_sep_b2(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_b2(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_b2(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_B2_DATA_1) then
                    int_sep_b2(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_b2(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_s2(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_S2_DATA_0) then
                    int_sep_s2(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_s2(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_s2(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_S2_DATA_1) then
                    int_sep_s2(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_s2(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_w3(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_W3_DATA_0) then
                    int_sep_w3(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_w3(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_w3(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_W3_DATA_1) then
                    int_sep_w3(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_w3(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_b3(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_B3_DATA_0) then
                    int_sep_b3(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_b3(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_b3(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_B3_DATA_1) then
                    int_sep_b3(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_b3(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_s3(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_S3_DATA_0) then
                    int_sep_s3(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_s3(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_s3(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_S3_DATA_1) then
                    int_sep_s3(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_s3(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c1_w(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C1_W_DATA_0) then
                    int_c1_w(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c1_w(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c1_w(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C1_W_DATA_1) then
                    int_c1_w(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c1_w(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c1_b(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C1_B_DATA_0) then
                    int_c1_b(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c1_b(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c1_b(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C1_B_DATA_1) then
                    int_c1_b(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c1_b(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c1_s(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C1_S_DATA_0) then
                    int_c1_s(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c1_s(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c1_s(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C1_S_DATA_1) then
                    int_c1_s(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c1_s(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c2_w(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C2_W_DATA_0) then
                    int_c2_w(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c2_w(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c2_w(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C2_W_DATA_1) then
                    int_c2_w(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c2_w(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c2_b(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C2_B_DATA_0) then
                    int_c2_b(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c2_b(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c2_b(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C2_B_DATA_1) then
                    int_c2_b(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c2_b(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c2_s(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C2_S_DATA_0) then
                    int_c2_s(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c2_s(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_c2_s(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_C2_S_DATA_1) then
                    int_c2_s(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_c2_s(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_r_buf(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_R_BUF_DATA_0) then
                    int_r_buf(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_r_buf(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_r_buf(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_R_BUF_DATA_1) then
                    int_r_buf(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_r_buf(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_y_buf(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_Y_BUF_DATA_0) then
                    int_sep_y_buf(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_y_buf(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sep_y_buf(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SEP_Y_BUF_DATA_1) then
                    int_sep_y_buf(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sep_y_buf(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ping_buf(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PING_BUF_DATA_0) then
                    int_ping_buf(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ping_buf(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ping_buf(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PING_BUF_DATA_1) then
                    int_ping_buf(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ping_buf(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_pong_buf(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PONG_BUF_DATA_0) then
                    int_pong_buf(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_pong_buf(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_pong_buf(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PONG_BUF_DATA_1) then
                    int_pong_buf(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_pong_buf(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_spike_buf(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SPIKE_BUF_DATA_0) then
                    int_spike_buf(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_spike_buf(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_spike_buf(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SPIKE_BUF_DATA_1) then
                    int_spike_buf(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_spike_buf(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_tmp_acc(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_TMP_ACC_DATA_0) then
                    int_tmp_acc(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_tmp_acc(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_tmp_acc(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_TMP_ACC_DATA_1) then
                    int_tmp_acc(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_tmp_acc(63 downto 32));
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------

end architecture behave;
