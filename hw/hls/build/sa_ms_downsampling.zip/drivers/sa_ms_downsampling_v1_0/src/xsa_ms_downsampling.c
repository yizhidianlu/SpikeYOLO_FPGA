// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsa_ms_downsampling.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSa_ms_downsampling_CfgInitialize(XSa_ms_downsampling *InstancePtr, XSa_ms_downsampling_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSa_ms_downsampling_Start(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSa_ms_downsampling_IsDone(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSa_ms_downsampling_IsIdle(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSa_ms_downsampling_IsReady(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSa_ms_downsampling_EnableAutoRestart(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSa_ms_downsampling_DisableAutoRestart(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL, 0);
}

void XSa_ms_downsampling_Set_T_in(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_T_IN_DATA, Data);
}

u32 XSa_ms_downsampling_Get_T_in(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_T_IN_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_C_in(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_C_IN_DATA, Data);
}

u32 XSa_ms_downsampling_Get_C_in(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_C_IN_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_C_out(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_C_OUT_DATA, Data);
}

u32 XSa_ms_downsampling_Get_C_out(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_C_OUT_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_H(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_H_DATA, Data);
}

u32 XSa_ms_downsampling_Get_H(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_H_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_W_r_r(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_W_R_R_DATA, Data);
}

u32 XSa_ms_downsampling_Get_W_r_r(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_W_R_R_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_K(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_K_DATA, Data);
}

u32 XSa_ms_downsampling_Get_K(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_K_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_stride(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_STRIDE_DATA, Data);
}

u32 XSa_ms_downsampling_Get_stride(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_STRIDE_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_pad(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_PAD_DATA, Data);
}

u32 XSa_ms_downsampling_Get_pad(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_PAD_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_groups(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_GROUPS_DATA, Data);
}

u32 XSa_ms_downsampling_Get_groups(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_GROUPS_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_first_layer(XSa_ms_downsampling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_FIRST_LAYER_DATA, Data);
}

u32 XSa_ms_downsampling_Get_first_layer(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_FIRST_LAYER_DATA);
    return Data;
}

void XSa_ms_downsampling_Set_x_i8(XSa_ms_downsampling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I8_DATA, (u32)(Data));
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I8_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_downsampling_Get_x_i8(XSa_ms_downsampling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I8_DATA);
    Data += (u64)XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I8_DATA + 4) << 32;
    return Data;
}

void XSa_ms_downsampling_Set_x_i32(XSa_ms_downsampling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I32_DATA, (u32)(Data));
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I32_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_downsampling_Get_x_i32(XSa_ms_downsampling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I32_DATA);
    Data += (u64)XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I32_DATA + 4) << 32;
    return Data;
}

void XSa_ms_downsampling_Set_y(XSa_ms_downsampling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_Y_DATA, (u32)(Data));
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_Y_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_downsampling_Get_y(XSa_ms_downsampling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_Y_DATA);
    Data += (u64)XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_Y_DATA + 4) << 32;
    return Data;
}

void XSa_ms_downsampling_Set_w(XSa_ms_downsampling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_W_DATA, (u32)(Data));
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_W_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_downsampling_Get_w(XSa_ms_downsampling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_W_DATA);
    Data += (u64)XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_W_DATA + 4) << 32;
    return Data;
}

void XSa_ms_downsampling_Set_bias(XSa_ms_downsampling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_BIAS_DATA, (u32)(Data));
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_downsampling_Get_bias(XSa_ms_downsampling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_BIAS_DATA);
    Data += (u64)XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XSa_ms_downsampling_Set_out_shift(XSa_ms_downsampling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_OUT_SHIFT_DATA, (u32)(Data));
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_OUT_SHIFT_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_downsampling_Get_out_shift(XSa_ms_downsampling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_OUT_SHIFT_DATA);
    Data += (u64)XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_OUT_SHIFT_DATA + 4) << 32;
    return Data;
}

void XSa_ms_downsampling_Set_spike_buf(XSa_ms_downsampling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_SPIKE_BUF_DATA, (u32)(Data));
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_SPIKE_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_downsampling_Get_spike_buf(XSa_ms_downsampling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_SPIKE_BUF_DATA);
    Data += (u64)XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_SPIKE_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_ms_downsampling_Set_tmp_acc(XSa_ms_downsampling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_TMP_ACC_DATA, (u32)(Data));
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_TMP_ACC_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_ms_downsampling_Get_tmp_acc(XSa_ms_downsampling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_TMP_ACC_DATA);
    Data += (u64)XSa_ms_downsampling_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_TMP_ACC_DATA + 4) << 32;
    return Data;
}

void XSa_ms_downsampling_InterruptGlobalEnable(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_GIE, 1);
}

void XSa_ms_downsampling_InterruptGlobalDisable(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_GIE, 0);
}

void XSa_ms_downsampling_InterruptEnable(XSa_ms_downsampling *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER);
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER, Register | Mask);
}

void XSa_ms_downsampling_InterruptDisable(XSa_ms_downsampling *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER);
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSa_ms_downsampling_InterruptClear(XSa_ms_downsampling *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_ISR, Mask);
}

u32 XSa_ms_downsampling_InterruptGetEnabled(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER);
}

u32 XSa_ms_downsampling_InterruptGetStatus(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_ISR);
}

