// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsa_ms_downsampling.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSa_ms_downsampling_CfgInitialize(XSa_ms_downsampling *InstancePtr, XSa_ms_downsampling_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSa_ms_downsampling_Start(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSa_ms_downsampling_IsDone(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSa_ms_downsampling_IsIdle(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSa_ms_downsampling_IsReady(XSa_ms_downsampling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSa_ms_downsampling_EnableAutoRestart(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSa_ms_downsampling_DisableAutoRestart(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL, 0);
}

void XSa_ms_downsampling_InterruptGlobalEnable(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_GIE, 1);
}

void XSa_ms_downsampling_InterruptGlobalDisable(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_GIE, 0);
}

void XSa_ms_downsampling_InterruptEnable(XSa_ms_downsampling *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER);
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER, Register | Mask);
}

void XSa_ms_downsampling_InterruptDisable(XSa_ms_downsampling *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER);
    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSa_ms_downsampling_InterruptClear(XSa_ms_downsampling *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_ms_downsampling_WriteReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_ISR, Mask);
}

u32 XSa_ms_downsampling_InterruptGetEnabled(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER);
}

u32 XSa_ms_downsampling_InterruptGetStatus(XSa_ms_downsampling *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_ms_downsampling_ReadReg(InstancePtr->Control_BaseAddress, XSA_MS_DOWNSAMPLING_CONTROL_ADDR_ISR);
}

