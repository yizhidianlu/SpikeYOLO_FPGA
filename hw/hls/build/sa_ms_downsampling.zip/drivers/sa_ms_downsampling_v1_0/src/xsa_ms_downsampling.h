// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSA_MS_DOWNSAMPLING_H
#define XSA_MS_DOWNSAMPLING_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsa_ms_downsampling_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XSa_ms_downsampling_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XSa_ms_downsampling;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSa_ms_downsampling_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSa_ms_downsampling_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSa_ms_downsampling_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSa_ms_downsampling_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XSa_ms_downsampling_Initialize(XSa_ms_downsampling *InstancePtr, UINTPTR BaseAddress);
XSa_ms_downsampling_Config* XSa_ms_downsampling_LookupConfig(UINTPTR BaseAddress);
#else
int XSa_ms_downsampling_Initialize(XSa_ms_downsampling *InstancePtr, u16 DeviceId);
XSa_ms_downsampling_Config* XSa_ms_downsampling_LookupConfig(u16 DeviceId);
#endif
int XSa_ms_downsampling_CfgInitialize(XSa_ms_downsampling *InstancePtr, XSa_ms_downsampling_Config *ConfigPtr);
#else
int XSa_ms_downsampling_Initialize(XSa_ms_downsampling *InstancePtr, const char* InstanceName);
int XSa_ms_downsampling_Release(XSa_ms_downsampling *InstancePtr);
#endif

void XSa_ms_downsampling_Start(XSa_ms_downsampling *InstancePtr);
u32 XSa_ms_downsampling_IsDone(XSa_ms_downsampling *InstancePtr);
u32 XSa_ms_downsampling_IsIdle(XSa_ms_downsampling *InstancePtr);
u32 XSa_ms_downsampling_IsReady(XSa_ms_downsampling *InstancePtr);
void XSa_ms_downsampling_EnableAutoRestart(XSa_ms_downsampling *InstancePtr);
void XSa_ms_downsampling_DisableAutoRestart(XSa_ms_downsampling *InstancePtr);


void XSa_ms_downsampling_InterruptGlobalEnable(XSa_ms_downsampling *InstancePtr);
void XSa_ms_downsampling_InterruptGlobalDisable(XSa_ms_downsampling *InstancePtr);
void XSa_ms_downsampling_InterruptEnable(XSa_ms_downsampling *InstancePtr, u32 Mask);
void XSa_ms_downsampling_InterruptDisable(XSa_ms_downsampling *InstancePtr, u32 Mask);
void XSa_ms_downsampling_InterruptClear(XSa_ms_downsampling *InstancePtr, u32 Mask);
u32 XSa_ms_downsampling_InterruptGetEnabled(XSa_ms_downsampling *InstancePtr);
u32 XSa_ms_downsampling_InterruptGetStatus(XSa_ms_downsampling *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
