// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of T_in
//        bit 31~0 - T_in[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of C_in
//        bit 31~0 - C_in[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of C_out
//        bit 31~0 - C_out[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of H
//        bit 31~0 - H[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of W_r_r
//        bit 31~0 - W_r_r[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of K
//        bit 31~0 - K[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of stride
//        bit 31~0 - stride[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of pad
//        bit 31~0 - pad[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of groups
//        bit 31~0 - groups[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of first_layer
//        bit 31~0 - first_layer[31:0] (Read/Write)
// 0x5c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_AP_CTRL          0x00
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_GIE              0x04
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_IER              0x08
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_ISR              0x0c
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_T_IN_DATA        0x10
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_T_IN_DATA        32
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_C_IN_DATA        0x18
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_C_IN_DATA        32
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_C_OUT_DATA       0x20
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_C_OUT_DATA       32
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_H_DATA           0x28
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_H_DATA           32
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_W_R_R_DATA       0x30
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_W_R_R_DATA       32
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_K_DATA           0x38
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_K_DATA           32
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_STRIDE_DATA      0x40
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_STRIDE_DATA      32
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_PAD_DATA         0x48
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_PAD_DATA         32
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_GROUPS_DATA      0x50
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_GROUPS_DATA      32
#define XSA_MS_DOWNSAMPLING_CONTROL_ADDR_FIRST_LAYER_DATA 0x58
#define XSA_MS_DOWNSAMPLING_CONTROL_BITS_FIRST_LAYER_DATA 32

// control_r
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of x_i8
//        bit 31~0 - x_i8[31:0] (Read/Write)
// 0x14 : Data signal of x_i8
//        bit 31~0 - x_i8[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of x_i32
//        bit 31~0 - x_i32[31:0] (Read/Write)
// 0x20 : Data signal of x_i32
//        bit 31~0 - x_i32[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of y
//        bit 31~0 - y[31:0] (Read/Write)
// 0x2c : Data signal of y
//        bit 31~0 - y[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of w
//        bit 31~0 - w[31:0] (Read/Write)
// 0x38 : Data signal of w
//        bit 31~0 - w[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of bias
//        bit 31~0 - bias[31:0] (Read/Write)
// 0x44 : Data signal of bias
//        bit 31~0 - bias[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of out_shift
//        bit 31~0 - out_shift[31:0] (Read/Write)
// 0x50 : Data signal of out_shift
//        bit 31~0 - out_shift[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of spike_buf
//        bit 31~0 - spike_buf[31:0] (Read/Write)
// 0x5c : Data signal of spike_buf
//        bit 31~0 - spike_buf[63:32] (Read/Write)
// 0x60 : reserved
// 0x64 : Data signal of tmp_acc
//        bit 31~0 - tmp_acc[31:0] (Read/Write)
// 0x68 : Data signal of tmp_acc
//        bit 31~0 - tmp_acc[63:32] (Read/Write)
// 0x6c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I8_DATA      0x10
#define XSA_MS_DOWNSAMPLING_CONTROL_R_BITS_X_I8_DATA      64
#define XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_X_I32_DATA     0x1c
#define XSA_MS_DOWNSAMPLING_CONTROL_R_BITS_X_I32_DATA     64
#define XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_Y_DATA         0x28
#define XSA_MS_DOWNSAMPLING_CONTROL_R_BITS_Y_DATA         64
#define XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_W_DATA         0x34
#define XSA_MS_DOWNSAMPLING_CONTROL_R_BITS_W_DATA         64
#define XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_BIAS_DATA      0x40
#define XSA_MS_DOWNSAMPLING_CONTROL_R_BITS_BIAS_DATA      64
#define XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_OUT_SHIFT_DATA 0x4c
#define XSA_MS_DOWNSAMPLING_CONTROL_R_BITS_OUT_SHIFT_DATA 64
#define XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_SPIKE_BUF_DATA 0x58
#define XSA_MS_DOWNSAMPLING_CONTROL_R_BITS_SPIKE_BUF_DATA 64
#define XSA_MS_DOWNSAMPLING_CONTROL_R_ADDR_TMP_ACC_DATA   0x64
#define XSA_MS_DOWNSAMPLING_CONTROL_R_BITS_TMP_ACC_DATA   64

