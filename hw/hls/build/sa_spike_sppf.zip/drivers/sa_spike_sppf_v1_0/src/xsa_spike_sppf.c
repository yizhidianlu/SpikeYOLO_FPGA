// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsa_spike_sppf.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSa_spike_sppf_CfgInitialize(XSa_spike_sppf *InstancePtr, XSa_spike_sppf_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSa_spike_sppf_Start(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSa_spike_sppf_IsDone(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSa_spike_sppf_IsIdle(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSa_spike_sppf_IsReady(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSa_spike_sppf_EnableAutoRestart(XSa_spike_sppf *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSa_spike_sppf_DisableAutoRestart(XSa_spike_sppf *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL, 0);
}

void XSa_spike_sppf_Set_T(XSa_spike_sppf *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_T_DATA, Data);
}

u32 XSa_spike_sppf_Get_T(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_T_DATA);
    return Data;
}

void XSa_spike_sppf_Set_C_in(XSa_spike_sppf *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_C_IN_DATA, Data);
}

u32 XSa_spike_sppf_Get_C_in(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_C_IN_DATA);
    return Data;
}

void XSa_spike_sppf_Set_C_mid(XSa_spike_sppf *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_C_MID_DATA, Data);
}

u32 XSa_spike_sppf_Get_C_mid(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_C_MID_DATA);
    return Data;
}

void XSa_spike_sppf_Set_C_out(XSa_spike_sppf *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_C_OUT_DATA, Data);
}

u32 XSa_spike_sppf_Get_C_out(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_C_OUT_DATA);
    return Data;
}

void XSa_spike_sppf_Set_H(XSa_spike_sppf *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_H_DATA, Data);
}

u32 XSa_spike_sppf_Get_H(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_H_DATA);
    return Data;
}

void XSa_spike_sppf_Set_W(XSa_spike_sppf *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_W_DATA, Data);
}

u32 XSa_spike_sppf_Get_W(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_W_DATA);
    return Data;
}

void XSa_spike_sppf_Set_k(XSa_spike_sppf *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_K_DATA, Data);
}

u32 XSa_spike_sppf_Get_k(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_K_DATA);
    return Data;
}

void XSa_spike_sppf_Set_x_in(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_X_IN_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_X_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_x_in(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_X_IN_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_X_IN_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_y_out(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_Y_OUT_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_Y_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_y_out(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_Y_OUT_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_Y_OUT_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_cv1_w(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_W_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_W_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_cv1_w(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_W_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_W_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_cv1_b(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_B_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_B_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_cv1_b(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_B_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_B_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_cv1_s(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_S_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_S_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_cv1_s(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_S_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_S_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_cv2_w(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_W_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_W_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_cv2_w(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_W_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_W_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_cv2_b(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_B_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_B_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_cv2_b(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_B_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_B_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_cv2_s(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_S_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_S_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_cv2_s(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_S_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_S_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_ping_buf(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_PING_BUF_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_PING_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_ping_buf(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_PING_BUF_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_PING_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_spk_buf(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPK_BUF_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPK_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_spk_buf(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPK_BUF_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPK_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_pool_buf1(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF1_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF1_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_pool_buf1(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF1_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF1_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_pool_buf2(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF2_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF2_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_pool_buf2(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF2_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF2_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_pool_buf3(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF3_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF3_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_pool_buf3(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF3_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF3_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_concat_buf(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CONCAT_BUF_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CONCAT_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_concat_buf(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CONCAT_BUF_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CONCAT_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_cat_i32_buf(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CAT_I32_BUF_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CAT_I32_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_cat_i32_buf(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CAT_I32_BUF_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_CAT_I32_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_spike_buf(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPIKE_BUF_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPIKE_BUF_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_spike_buf(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPIKE_BUF_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPIKE_BUF_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_Set_tmp_acc(XSa_spike_sppf *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_TMP_ACC_DATA, (u32)(Data));
    XSa_spike_sppf_WriteReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_TMP_ACC_DATA + 4, (u32)(Data >> 32));
}

u64 XSa_spike_sppf_Get_tmp_acc(XSa_spike_sppf *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_TMP_ACC_DATA);
    Data += (u64)XSa_spike_sppf_ReadReg(InstancePtr->Control_r_BaseAddress, XSA_SPIKE_SPPF_CONTROL_R_ADDR_TMP_ACC_DATA + 4) << 32;
    return Data;
}

void XSa_spike_sppf_InterruptGlobalEnable(XSa_spike_sppf *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_GIE, 1);
}

void XSa_spike_sppf_InterruptGlobalDisable(XSa_spike_sppf *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_GIE, 0);
}

void XSa_spike_sppf_InterruptEnable(XSa_spike_sppf *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER);
    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER, Register | Mask);
}

void XSa_spike_sppf_InterruptDisable(XSa_spike_sppf *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER);
    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSa_spike_sppf_InterruptClear(XSa_spike_sppf *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_ISR, Mask);
}

u32 XSa_spike_sppf_InterruptGetEnabled(XSa_spike_sppf *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER);
}

u32 XSa_spike_sppf_InterruptGetStatus(XSa_spike_sppf *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_ISR);
}

