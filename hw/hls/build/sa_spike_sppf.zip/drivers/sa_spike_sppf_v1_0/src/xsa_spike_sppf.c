// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsa_spike_sppf.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSa_spike_sppf_CfgInitialize(XSa_spike_sppf *InstancePtr, XSa_spike_sppf_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSa_spike_sppf_Start(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSa_spike_sppf_IsDone(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSa_spike_sppf_IsIdle(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSa_spike_sppf_IsReady(XSa_spike_sppf *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSa_spike_sppf_EnableAutoRestart(XSa_spike_sppf *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSa_spike_sppf_DisableAutoRestart(XSa_spike_sppf *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL, 0);
}

void XSa_spike_sppf_InterruptGlobalEnable(XSa_spike_sppf *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_GIE, 1);
}

void XSa_spike_sppf_InterruptGlobalDisable(XSa_spike_sppf *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_GIE, 0);
}

void XSa_spike_sppf_InterruptEnable(XSa_spike_sppf *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER);
    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER, Register | Mask);
}

void XSa_spike_sppf_InterruptDisable(XSa_spike_sppf *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER);
    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSa_spike_sppf_InterruptClear(XSa_spike_sppf *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_spike_sppf_WriteReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_ISR, Mask);
}

u32 XSa_spike_sppf_InterruptGetEnabled(XSa_spike_sppf *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_IER);
}

u32 XSa_spike_sppf_InterruptGetStatus(XSa_spike_sppf *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_spike_sppf_ReadReg(InstancePtr->Control_BaseAddress, XSA_SPIKE_SPPF_CONTROL_ADDR_ISR);
}

