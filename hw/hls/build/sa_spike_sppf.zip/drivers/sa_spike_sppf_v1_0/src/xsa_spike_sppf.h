// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSA_SPIKE_SPPF_H
#define XSA_SPIKE_SPPF_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsa_spike_sppf_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XSa_spike_sppf_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XSa_spike_sppf;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSa_spike_sppf_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSa_spike_sppf_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSa_spike_sppf_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSa_spike_sppf_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XSa_spike_sppf_Initialize(XSa_spike_sppf *InstancePtr, UINTPTR BaseAddress);
XSa_spike_sppf_Config* XSa_spike_sppf_LookupConfig(UINTPTR BaseAddress);
#else
int XSa_spike_sppf_Initialize(XSa_spike_sppf *InstancePtr, u16 DeviceId);
XSa_spike_sppf_Config* XSa_spike_sppf_LookupConfig(u16 DeviceId);
#endif
int XSa_spike_sppf_CfgInitialize(XSa_spike_sppf *InstancePtr, XSa_spike_sppf_Config *ConfigPtr);
#else
int XSa_spike_sppf_Initialize(XSa_spike_sppf *InstancePtr, const char* InstanceName);
int XSa_spike_sppf_Release(XSa_spike_sppf *InstancePtr);
#endif

void XSa_spike_sppf_Start(XSa_spike_sppf *InstancePtr);
u32 XSa_spike_sppf_IsDone(XSa_spike_sppf *InstancePtr);
u32 XSa_spike_sppf_IsIdle(XSa_spike_sppf *InstancePtr);
u32 XSa_spike_sppf_IsReady(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_EnableAutoRestart(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_DisableAutoRestart(XSa_spike_sppf *InstancePtr);

void XSa_spike_sppf_Set_T(XSa_spike_sppf *InstancePtr, u32 Data);
u32 XSa_spike_sppf_Get_T(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_C_in(XSa_spike_sppf *InstancePtr, u32 Data);
u32 XSa_spike_sppf_Get_C_in(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_C_mid(XSa_spike_sppf *InstancePtr, u32 Data);
u32 XSa_spike_sppf_Get_C_mid(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_C_out(XSa_spike_sppf *InstancePtr, u32 Data);
u32 XSa_spike_sppf_Get_C_out(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_H(XSa_spike_sppf *InstancePtr, u32 Data);
u32 XSa_spike_sppf_Get_H(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_W(XSa_spike_sppf *InstancePtr, u32 Data);
u32 XSa_spike_sppf_Get_W(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_k(XSa_spike_sppf *InstancePtr, u32 Data);
u32 XSa_spike_sppf_Get_k(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_x_in(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_x_in(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_y_out(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_y_out(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_cv1_w(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_cv1_w(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_cv1_b(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_cv1_b(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_cv1_s(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_cv1_s(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_cv2_w(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_cv2_w(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_cv2_b(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_cv2_b(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_cv2_s(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_cv2_s(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_ping_buf(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_ping_buf(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_spk_buf(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_spk_buf(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_pool_buf1(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_pool_buf1(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_pool_buf2(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_pool_buf2(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_pool_buf3(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_pool_buf3(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_concat_buf(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_concat_buf(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_cat_i32_buf(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_cat_i32_buf(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_spike_buf(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_spike_buf(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_Set_tmp_acc(XSa_spike_sppf *InstancePtr, u64 Data);
u64 XSa_spike_sppf_Get_tmp_acc(XSa_spike_sppf *InstancePtr);

void XSa_spike_sppf_InterruptGlobalEnable(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_InterruptGlobalDisable(XSa_spike_sppf *InstancePtr);
void XSa_spike_sppf_InterruptEnable(XSa_spike_sppf *InstancePtr, u32 Mask);
void XSa_spike_sppf_InterruptDisable(XSa_spike_sppf *InstancePtr, u32 Mask);
void XSa_spike_sppf_InterruptClear(XSa_spike_sppf *InstancePtr, u32 Mask);
u32 XSa_spike_sppf_InterruptGetEnabled(XSa_spike_sppf *InstancePtr);
u32 XSa_spike_sppf_InterruptGetStatus(XSa_spike_sppf *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
