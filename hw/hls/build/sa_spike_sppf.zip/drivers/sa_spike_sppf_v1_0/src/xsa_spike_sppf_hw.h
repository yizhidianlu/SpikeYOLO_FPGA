// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of T
//        bit 31~0 - T[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of C_in
//        bit 31~0 - C_in[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of C_mid
//        bit 31~0 - C_mid[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of C_out
//        bit 31~0 - C_out[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of H
//        bit 31~0 - H[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of W
//        bit 31~0 - W[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of k
//        bit 31~0 - k[31:0] (Read/Write)
// 0x44 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_SPIKE_SPPF_CONTROL_ADDR_AP_CTRL    0x00
#define XSA_SPIKE_SPPF_CONTROL_ADDR_GIE        0x04
#define XSA_SPIKE_SPPF_CONTROL_ADDR_IER        0x08
#define XSA_SPIKE_SPPF_CONTROL_ADDR_ISR        0x0c
#define XSA_SPIKE_SPPF_CONTROL_ADDR_T_DATA     0x10
#define XSA_SPIKE_SPPF_CONTROL_BITS_T_DATA     32
#define XSA_SPIKE_SPPF_CONTROL_ADDR_C_IN_DATA  0x18
#define XSA_SPIKE_SPPF_CONTROL_BITS_C_IN_DATA  32
#define XSA_SPIKE_SPPF_CONTROL_ADDR_C_MID_DATA 0x20
#define XSA_SPIKE_SPPF_CONTROL_BITS_C_MID_DATA 32
#define XSA_SPIKE_SPPF_CONTROL_ADDR_C_OUT_DATA 0x28
#define XSA_SPIKE_SPPF_CONTROL_BITS_C_OUT_DATA 32
#define XSA_SPIKE_SPPF_CONTROL_ADDR_H_DATA     0x30
#define XSA_SPIKE_SPPF_CONTROL_BITS_H_DATA     32
#define XSA_SPIKE_SPPF_CONTROL_ADDR_W_DATA     0x38
#define XSA_SPIKE_SPPF_CONTROL_BITS_W_DATA     32
#define XSA_SPIKE_SPPF_CONTROL_ADDR_K_DATA     0x40
#define XSA_SPIKE_SPPF_CONTROL_BITS_K_DATA     32

// control_r
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of x_in
//        bit 31~0 - x_in[31:0] (Read/Write)
// 0x14 : Data signal of x_in
//        bit 31~0 - x_in[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of y_out
//        bit 31~0 - y_out[31:0] (Read/Write)
// 0x20 : Data signal of y_out
//        bit 31~0 - y_out[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of cv1_w
//        bit 31~0 - cv1_w[31:0] (Read/Write)
// 0x2c : Data signal of cv1_w
//        bit 31~0 - cv1_w[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of cv1_b
//        bit 31~0 - cv1_b[31:0] (Read/Write)
// 0x38 : Data signal of cv1_b
//        bit 31~0 - cv1_b[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of cv1_s
//        bit 31~0 - cv1_s[31:0] (Read/Write)
// 0x44 : Data signal of cv1_s
//        bit 31~0 - cv1_s[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of cv2_w
//        bit 31~0 - cv2_w[31:0] (Read/Write)
// 0x50 : Data signal of cv2_w
//        bit 31~0 - cv2_w[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of cv2_b
//        bit 31~0 - cv2_b[31:0] (Read/Write)
// 0x5c : Data signal of cv2_b
//        bit 31~0 - cv2_b[63:32] (Read/Write)
// 0x60 : reserved
// 0x64 : Data signal of cv2_s
//        bit 31~0 - cv2_s[31:0] (Read/Write)
// 0x68 : Data signal of cv2_s
//        bit 31~0 - cv2_s[63:32] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of ping_buf
//        bit 31~0 - ping_buf[31:0] (Read/Write)
// 0x74 : Data signal of ping_buf
//        bit 31~0 - ping_buf[63:32] (Read/Write)
// 0x78 : reserved
// 0x7c : Data signal of spk_buf
//        bit 31~0 - spk_buf[31:0] (Read/Write)
// 0x80 : Data signal of spk_buf
//        bit 31~0 - spk_buf[63:32] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of pool_buf1
//        bit 31~0 - pool_buf1[31:0] (Read/Write)
// 0x8c : Data signal of pool_buf1
//        bit 31~0 - pool_buf1[63:32] (Read/Write)
// 0x90 : reserved
// 0x94 : Data signal of pool_buf2
//        bit 31~0 - pool_buf2[31:0] (Read/Write)
// 0x98 : Data signal of pool_buf2
//        bit 31~0 - pool_buf2[63:32] (Read/Write)
// 0x9c : reserved
// 0xa0 : Data signal of pool_buf3
//        bit 31~0 - pool_buf3[31:0] (Read/Write)
// 0xa4 : Data signal of pool_buf3
//        bit 31~0 - pool_buf3[63:32] (Read/Write)
// 0xa8 : reserved
// 0xac : Data signal of concat_buf
//        bit 31~0 - concat_buf[31:0] (Read/Write)
// 0xb0 : Data signal of concat_buf
//        bit 31~0 - concat_buf[63:32] (Read/Write)
// 0xb4 : reserved
// 0xb8 : Data signal of cat_i32_buf
//        bit 31~0 - cat_i32_buf[31:0] (Read/Write)
// 0xbc : Data signal of cat_i32_buf
//        bit 31~0 - cat_i32_buf[63:32] (Read/Write)
// 0xc0 : reserved
// 0xc4 : Data signal of spike_buf
//        bit 31~0 - spike_buf[31:0] (Read/Write)
// 0xc8 : Data signal of spike_buf
//        bit 31~0 - spike_buf[63:32] (Read/Write)
// 0xcc : reserved
// 0xd0 : Data signal of tmp_acc
//        bit 31~0 - tmp_acc[31:0] (Read/Write)
// 0xd4 : Data signal of tmp_acc
//        bit 31~0 - tmp_acc[63:32] (Read/Write)
// 0xd8 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_X_IN_DATA        0x10
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_X_IN_DATA        64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_Y_OUT_DATA       0x1c
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_Y_OUT_DATA       64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_W_DATA       0x28
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_CV1_W_DATA       64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_B_DATA       0x34
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_CV1_B_DATA       64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV1_S_DATA       0x40
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_CV1_S_DATA       64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_W_DATA       0x4c
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_CV2_W_DATA       64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_B_DATA       0x58
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_CV2_B_DATA       64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_CV2_S_DATA       0x64
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_CV2_S_DATA       64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_PING_BUF_DATA    0x70
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_PING_BUF_DATA    64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPK_BUF_DATA     0x7c
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_SPK_BUF_DATA     64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF1_DATA   0x88
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_POOL_BUF1_DATA   64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF2_DATA   0x94
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_POOL_BUF2_DATA   64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_POOL_BUF3_DATA   0xa0
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_POOL_BUF3_DATA   64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_CONCAT_BUF_DATA  0xac
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_CONCAT_BUF_DATA  64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_CAT_I32_BUF_DATA 0xb8
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_CAT_I32_BUF_DATA 64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_SPIKE_BUF_DATA   0xc4
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_SPIKE_BUF_DATA   64
#define XSA_SPIKE_SPPF_CONTROL_R_ADDR_TMP_ACC_DATA     0xd0
#define XSA_SPIKE_SPPF_CONTROL_R_BITS_TMP_ACC_DATA     64

