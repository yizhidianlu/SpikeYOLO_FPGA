// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module sa_spike_sppf_control_r_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 8,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire [63:0]                   x_in,
    output wire [63:0]                   y_out,
    output wire [63:0]                   cv1_w,
    output wire [63:0]                   cv1_b,
    output wire [63:0]                   cv1_s,
    output wire [63:0]                   cv2_w,
    output wire [63:0]                   cv2_b,
    output wire [63:0]                   cv2_s,
    output wire [63:0]                   ping_buf,
    output wire [63:0]                   spk_buf,
    output wire [63:0]                   pool_buf1,
    output wire [63:0]                   pool_buf2,
    output wire [63:0]                   pool_buf3,
    output wire [63:0]                   concat_buf,
    output wire [63:0]                   cat_i32_buf,
    output wire [63:0]                   spike_buf,
    output wire [63:0]                   tmp_acc
);
//------------------------Address Info-------------------
// Protocol Used: ap_ctrl_none
//
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of x_in
//        bit 31~0 - x_in[31:0] (Read/Write)
// 0x14 : Data signal of x_in
//        bit 31~0 - x_in[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of y_out
//        bit 31~0 - y_out[31:0] (Read/Write)
// 0x20 : Data signal of y_out
//        bit 31~0 - y_out[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of cv1_w
//        bit 31~0 - cv1_w[31:0] (Read/Write)
// 0x2c : Data signal of cv1_w
//        bit 31~0 - cv1_w[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of cv1_b
//        bit 31~0 - cv1_b[31:0] (Read/Write)
// 0x38 : Data signal of cv1_b
//        bit 31~0 - cv1_b[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of cv1_s
//        bit 31~0 - cv1_s[31:0] (Read/Write)
// 0x44 : Data signal of cv1_s
//        bit 31~0 - cv1_s[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of cv2_w
//        bit 31~0 - cv2_w[31:0] (Read/Write)
// 0x50 : Data signal of cv2_w
//        bit 31~0 - cv2_w[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of cv2_b
//        bit 31~0 - cv2_b[31:0] (Read/Write)
// 0x5c : Data signal of cv2_b
//        bit 31~0 - cv2_b[63:32] (Read/Write)
// 0x60 : reserved
// 0x64 : Data signal of cv2_s
//        bit 31~0 - cv2_s[31:0] (Read/Write)
// 0x68 : Data signal of cv2_s
//        bit 31~0 - cv2_s[63:32] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of ping_buf
//        bit 31~0 - ping_buf[31:0] (Read/Write)
// 0x74 : Data signal of ping_buf
//        bit 31~0 - ping_buf[63:32] (Read/Write)
// 0x78 : reserved
// 0x7c : Data signal of spk_buf
//        bit 31~0 - spk_buf[31:0] (Read/Write)
// 0x80 : Data signal of spk_buf
//        bit 31~0 - spk_buf[63:32] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of pool_buf1
//        bit 31~0 - pool_buf1[31:0] (Read/Write)
// 0x8c : Data signal of pool_buf1
//        bit 31~0 - pool_buf1[63:32] (Read/Write)
// 0x90 : reserved
// 0x94 : Data signal of pool_buf2
//        bit 31~0 - pool_buf2[31:0] (Read/Write)
// 0x98 : Data signal of pool_buf2
//        bit 31~0 - pool_buf2[63:32] (Read/Write)
// 0x9c : reserved
// 0xa0 : Data signal of pool_buf3
//        bit 31~0 - pool_buf3[31:0] (Read/Write)
// 0xa4 : Data signal of pool_buf3
//        bit 31~0 - pool_buf3[63:32] (Read/Write)
// 0xa8 : reserved
// 0xac : Data signal of concat_buf
//        bit 31~0 - concat_buf[31:0] (Read/Write)
// 0xb0 : Data signal of concat_buf
//        bit 31~0 - concat_buf[63:32] (Read/Write)
// 0xb4 : reserved
// 0xb8 : Data signal of cat_i32_buf
//        bit 31~0 - cat_i32_buf[31:0] (Read/Write)
// 0xbc : Data signal of cat_i32_buf
//        bit 31~0 - cat_i32_buf[63:32] (Read/Write)
// 0xc0 : reserved
// 0xc4 : Data signal of spike_buf
//        bit 31~0 - spike_buf[31:0] (Read/Write)
// 0xc8 : Data signal of spike_buf
//        bit 31~0 - spike_buf[63:32] (Read/Write)
// 0xcc : reserved
// 0xd0 : Data signal of tmp_acc
//        bit 31~0 - tmp_acc[31:0] (Read/Write)
// 0xd4 : Data signal of tmp_acc
//        bit 31~0 - tmp_acc[63:32] (Read/Write)
// 0xd8 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_X_IN_DATA_0        = 8'h10,
    ADDR_X_IN_DATA_1        = 8'h14,
    ADDR_X_IN_CTRL          = 8'h18,
    ADDR_Y_OUT_DATA_0       = 8'h1c,
    ADDR_Y_OUT_DATA_1       = 8'h20,
    ADDR_Y_OUT_CTRL         = 8'h24,
    ADDR_CV1_W_DATA_0       = 8'h28,
    ADDR_CV1_W_DATA_1       = 8'h2c,
    ADDR_CV1_W_CTRL         = 8'h30,
    ADDR_CV1_B_DATA_0       = 8'h34,
    ADDR_CV1_B_DATA_1       = 8'h38,
    ADDR_CV1_B_CTRL         = 8'h3c,
    ADDR_CV1_S_DATA_0       = 8'h40,
    ADDR_CV1_S_DATA_1       = 8'h44,
    ADDR_CV1_S_CTRL         = 8'h48,
    ADDR_CV2_W_DATA_0       = 8'h4c,
    ADDR_CV2_W_DATA_1       = 8'h50,
    ADDR_CV2_W_CTRL         = 8'h54,
    ADDR_CV2_B_DATA_0       = 8'h58,
    ADDR_CV2_B_DATA_1       = 8'h5c,
    ADDR_CV2_B_CTRL         = 8'h60,
    ADDR_CV2_S_DATA_0       = 8'h64,
    ADDR_CV2_S_DATA_1       = 8'h68,
    ADDR_CV2_S_CTRL         = 8'h6c,
    ADDR_PING_BUF_DATA_0    = 8'h70,
    ADDR_PING_BUF_DATA_1    = 8'h74,
    ADDR_PING_BUF_CTRL      = 8'h78,
    ADDR_SPK_BUF_DATA_0     = 8'h7c,
    ADDR_SPK_BUF_DATA_1     = 8'h80,
    ADDR_SPK_BUF_CTRL       = 8'h84,
    ADDR_POOL_BUF1_DATA_0   = 8'h88,
    ADDR_POOL_BUF1_DATA_1   = 8'h8c,
    ADDR_POOL_BUF1_CTRL     = 8'h90,
    ADDR_POOL_BUF2_DATA_0   = 8'h94,
    ADDR_POOL_BUF2_DATA_1   = 8'h98,
    ADDR_POOL_BUF2_CTRL     = 8'h9c,
    ADDR_POOL_BUF3_DATA_0   = 8'ha0,
    ADDR_POOL_BUF3_DATA_1   = 8'ha4,
    ADDR_POOL_BUF3_CTRL     = 8'ha8,
    ADDR_CONCAT_BUF_DATA_0  = 8'hac,
    ADDR_CONCAT_BUF_DATA_1  = 8'hb0,
    ADDR_CONCAT_BUF_CTRL    = 8'hb4,
    ADDR_CAT_I32_BUF_DATA_0 = 8'hb8,
    ADDR_CAT_I32_BUF_DATA_1 = 8'hbc,
    ADDR_CAT_I32_BUF_CTRL   = 8'hc0,
    ADDR_SPIKE_BUF_DATA_0   = 8'hc4,
    ADDR_SPIKE_BUF_DATA_1   = 8'hc8,
    ADDR_SPIKE_BUF_CTRL     = 8'hcc,
    ADDR_TMP_ACC_DATA_0     = 8'hd0,
    ADDR_TMP_ACC_DATA_1     = 8'hd4,
    ADDR_TMP_ACC_CTRL       = 8'hd8,
    WRIDLE                  = 2'd0,
    WRDATA                  = 2'd1,
    WRRESP                  = 2'd2,
    WRRESET                 = 2'd3,
    RDIDLE                  = 2'd0,
    RDDATA                  = 2'd1,
    RDRESET                 = 2'd2,
    ADDR_BITS                = 8;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg  [63:0]                   int_x_in = 'b0;
    reg  [63:0]                   int_y_out = 'b0;
    reg  [63:0]                   int_cv1_w = 'b0;
    reg  [63:0]                   int_cv1_b = 'b0;
    reg  [63:0]                   int_cv1_s = 'b0;
    reg  [63:0]                   int_cv2_w = 'b0;
    reg  [63:0]                   int_cv2_b = 'b0;
    reg  [63:0]                   int_cv2_s = 'b0;
    reg  [63:0]                   int_ping_buf = 'b0;
    reg  [63:0]                   int_spk_buf = 'b0;
    reg  [63:0]                   int_pool_buf1 = 'b0;
    reg  [63:0]                   int_pool_buf2 = 'b0;
    reg  [63:0]                   int_pool_buf3 = 'b0;
    reg  [63:0]                   int_concat_buf = 'b0;
    reg  [63:0]                   int_cat_i32_buf = 'b0;
    reg  [63:0]                   int_spike_buf = 'b0;
    reg  [63:0]                   int_tmp_acc = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BRESP   = 2'b00;  // OKAY
assign BVALID  = (wstate == WRRESP);
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= {AWADDR[ADDR_BITS-1:2], {2{1'b0}}};
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_X_IN_DATA_0: begin
                    rdata <= int_x_in[31:0];
                end
                ADDR_X_IN_DATA_1: begin
                    rdata <= int_x_in[63:32];
                end
                ADDR_Y_OUT_DATA_0: begin
                    rdata <= int_y_out[31:0];
                end
                ADDR_Y_OUT_DATA_1: begin
                    rdata <= int_y_out[63:32];
                end
                ADDR_CV1_W_DATA_0: begin
                    rdata <= int_cv1_w[31:0];
                end
                ADDR_CV1_W_DATA_1: begin
                    rdata <= int_cv1_w[63:32];
                end
                ADDR_CV1_B_DATA_0: begin
                    rdata <= int_cv1_b[31:0];
                end
                ADDR_CV1_B_DATA_1: begin
                    rdata <= int_cv1_b[63:32];
                end
                ADDR_CV1_S_DATA_0: begin
                    rdata <= int_cv1_s[31:0];
                end
                ADDR_CV1_S_DATA_1: begin
                    rdata <= int_cv1_s[63:32];
                end
                ADDR_CV2_W_DATA_0: begin
                    rdata <= int_cv2_w[31:0];
                end
                ADDR_CV2_W_DATA_1: begin
                    rdata <= int_cv2_w[63:32];
                end
                ADDR_CV2_B_DATA_0: begin
                    rdata <= int_cv2_b[31:0];
                end
                ADDR_CV2_B_DATA_1: begin
                    rdata <= int_cv2_b[63:32];
                end
                ADDR_CV2_S_DATA_0: begin
                    rdata <= int_cv2_s[31:0];
                end
                ADDR_CV2_S_DATA_1: begin
                    rdata <= int_cv2_s[63:32];
                end
                ADDR_PING_BUF_DATA_0: begin
                    rdata <= int_ping_buf[31:0];
                end
                ADDR_PING_BUF_DATA_1: begin
                    rdata <= int_ping_buf[63:32];
                end
                ADDR_SPK_BUF_DATA_0: begin
                    rdata <= int_spk_buf[31:0];
                end
                ADDR_SPK_BUF_DATA_1: begin
                    rdata <= int_spk_buf[63:32];
                end
                ADDR_POOL_BUF1_DATA_0: begin
                    rdata <= int_pool_buf1[31:0];
                end
                ADDR_POOL_BUF1_DATA_1: begin
                    rdata <= int_pool_buf1[63:32];
                end
                ADDR_POOL_BUF2_DATA_0: begin
                    rdata <= int_pool_buf2[31:0];
                end
                ADDR_POOL_BUF2_DATA_1: begin
                    rdata <= int_pool_buf2[63:32];
                end
                ADDR_POOL_BUF3_DATA_0: begin
                    rdata <= int_pool_buf3[31:0];
                end
                ADDR_POOL_BUF3_DATA_1: begin
                    rdata <= int_pool_buf3[63:32];
                end
                ADDR_CONCAT_BUF_DATA_0: begin
                    rdata <= int_concat_buf[31:0];
                end
                ADDR_CONCAT_BUF_DATA_1: begin
                    rdata <= int_concat_buf[63:32];
                end
                ADDR_CAT_I32_BUF_DATA_0: begin
                    rdata <= int_cat_i32_buf[31:0];
                end
                ADDR_CAT_I32_BUF_DATA_1: begin
                    rdata <= int_cat_i32_buf[63:32];
                end
                ADDR_SPIKE_BUF_DATA_0: begin
                    rdata <= int_spike_buf[31:0];
                end
                ADDR_SPIKE_BUF_DATA_1: begin
                    rdata <= int_spike_buf[63:32];
                end
                ADDR_TMP_ACC_DATA_0: begin
                    rdata <= int_tmp_acc[31:0];
                end
                ADDR_TMP_ACC_DATA_1: begin
                    rdata <= int_tmp_acc[63:32];
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign x_in        = int_x_in;
assign y_out       = int_y_out;
assign cv1_w       = int_cv1_w;
assign cv1_b       = int_cv1_b;
assign cv1_s       = int_cv1_s;
assign cv2_w       = int_cv2_w;
assign cv2_b       = int_cv2_b;
assign cv2_s       = int_cv2_s;
assign ping_buf    = int_ping_buf;
assign spk_buf     = int_spk_buf;
assign pool_buf1   = int_pool_buf1;
assign pool_buf2   = int_pool_buf2;
assign pool_buf3   = int_pool_buf3;
assign concat_buf  = int_concat_buf;
assign cat_i32_buf = int_cat_i32_buf;
assign spike_buf   = int_spike_buf;
assign tmp_acc     = int_tmp_acc;
// int_x_in[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_x_in[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_X_IN_DATA_0)
            int_x_in[31:0] <= (WDATA[31:0] & wmask) | (int_x_in[31:0] & ~wmask);
    end
end

// int_x_in[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_x_in[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_X_IN_DATA_1)
            int_x_in[63:32] <= (WDATA[31:0] & wmask) | (int_x_in[63:32] & ~wmask);
    end
end

// int_y_out[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_y_out[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_Y_OUT_DATA_0)
            int_y_out[31:0] <= (WDATA[31:0] & wmask) | (int_y_out[31:0] & ~wmask);
    end
end

// int_y_out[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_y_out[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_Y_OUT_DATA_1)
            int_y_out[63:32] <= (WDATA[31:0] & wmask) | (int_y_out[63:32] & ~wmask);
    end
end

// int_cv1_w[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv1_w[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV1_W_DATA_0)
            int_cv1_w[31:0] <= (WDATA[31:0] & wmask) | (int_cv1_w[31:0] & ~wmask);
    end
end

// int_cv1_w[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv1_w[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV1_W_DATA_1)
            int_cv1_w[63:32] <= (WDATA[31:0] & wmask) | (int_cv1_w[63:32] & ~wmask);
    end
end

// int_cv1_b[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv1_b[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV1_B_DATA_0)
            int_cv1_b[31:0] <= (WDATA[31:0] & wmask) | (int_cv1_b[31:0] & ~wmask);
    end
end

// int_cv1_b[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv1_b[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV1_B_DATA_1)
            int_cv1_b[63:32] <= (WDATA[31:0] & wmask) | (int_cv1_b[63:32] & ~wmask);
    end
end

// int_cv1_s[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv1_s[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV1_S_DATA_0)
            int_cv1_s[31:0] <= (WDATA[31:0] & wmask) | (int_cv1_s[31:0] & ~wmask);
    end
end

// int_cv1_s[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv1_s[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV1_S_DATA_1)
            int_cv1_s[63:32] <= (WDATA[31:0] & wmask) | (int_cv1_s[63:32] & ~wmask);
    end
end

// int_cv2_w[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv2_w[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV2_W_DATA_0)
            int_cv2_w[31:0] <= (WDATA[31:0] & wmask) | (int_cv2_w[31:0] & ~wmask);
    end
end

// int_cv2_w[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv2_w[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV2_W_DATA_1)
            int_cv2_w[63:32] <= (WDATA[31:0] & wmask) | (int_cv2_w[63:32] & ~wmask);
    end
end

// int_cv2_b[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv2_b[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV2_B_DATA_0)
            int_cv2_b[31:0] <= (WDATA[31:0] & wmask) | (int_cv2_b[31:0] & ~wmask);
    end
end

// int_cv2_b[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv2_b[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV2_B_DATA_1)
            int_cv2_b[63:32] <= (WDATA[31:0] & wmask) | (int_cv2_b[63:32] & ~wmask);
    end
end

// int_cv2_s[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv2_s[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV2_S_DATA_0)
            int_cv2_s[31:0] <= (WDATA[31:0] & wmask) | (int_cv2_s[31:0] & ~wmask);
    end
end

// int_cv2_s[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_cv2_s[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CV2_S_DATA_1)
            int_cv2_s[63:32] <= (WDATA[31:0] & wmask) | (int_cv2_s[63:32] & ~wmask);
    end
end

// int_ping_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_ping_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PING_BUF_DATA_0)
            int_ping_buf[31:0] <= (WDATA[31:0] & wmask) | (int_ping_buf[31:0] & ~wmask);
    end
end

// int_ping_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_ping_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PING_BUF_DATA_1)
            int_ping_buf[63:32] <= (WDATA[31:0] & wmask) | (int_ping_buf[63:32] & ~wmask);
    end
end

// int_spk_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_spk_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SPK_BUF_DATA_0)
            int_spk_buf[31:0] <= (WDATA[31:0] & wmask) | (int_spk_buf[31:0] & ~wmask);
    end
end

// int_spk_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_spk_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SPK_BUF_DATA_1)
            int_spk_buf[63:32] <= (WDATA[31:0] & wmask) | (int_spk_buf[63:32] & ~wmask);
    end
end

// int_pool_buf1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pool_buf1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POOL_BUF1_DATA_0)
            int_pool_buf1[31:0] <= (WDATA[31:0] & wmask) | (int_pool_buf1[31:0] & ~wmask);
    end
end

// int_pool_buf1[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_pool_buf1[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POOL_BUF1_DATA_1)
            int_pool_buf1[63:32] <= (WDATA[31:0] & wmask) | (int_pool_buf1[63:32] & ~wmask);
    end
end

// int_pool_buf2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pool_buf2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POOL_BUF2_DATA_0)
            int_pool_buf2[31:0] <= (WDATA[31:0] & wmask) | (int_pool_buf2[31:0] & ~wmask);
    end
end

// int_pool_buf2[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_pool_buf2[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POOL_BUF2_DATA_1)
            int_pool_buf2[63:32] <= (WDATA[31:0] & wmask) | (int_pool_buf2[63:32] & ~wmask);
    end
end

// int_pool_buf3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pool_buf3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POOL_BUF3_DATA_0)
            int_pool_buf3[31:0] <= (WDATA[31:0] & wmask) | (int_pool_buf3[31:0] & ~wmask);
    end
end

// int_pool_buf3[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_pool_buf3[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POOL_BUF3_DATA_1)
            int_pool_buf3[63:32] <= (WDATA[31:0] & wmask) | (int_pool_buf3[63:32] & ~wmask);
    end
end

// int_concat_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_concat_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CONCAT_BUF_DATA_0)
            int_concat_buf[31:0] <= (WDATA[31:0] & wmask) | (int_concat_buf[31:0] & ~wmask);
    end
end

// int_concat_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_concat_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CONCAT_BUF_DATA_1)
            int_concat_buf[63:32] <= (WDATA[31:0] & wmask) | (int_concat_buf[63:32] & ~wmask);
    end
end

// int_cat_i32_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_cat_i32_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CAT_I32_BUF_DATA_0)
            int_cat_i32_buf[31:0] <= (WDATA[31:0] & wmask) | (int_cat_i32_buf[31:0] & ~wmask);
    end
end

// int_cat_i32_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_cat_i32_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_CAT_I32_BUF_DATA_1)
            int_cat_i32_buf[63:32] <= (WDATA[31:0] & wmask) | (int_cat_i32_buf[63:32] & ~wmask);
    end
end

// int_spike_buf[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_spike_buf[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SPIKE_BUF_DATA_0)
            int_spike_buf[31:0] <= (WDATA[31:0] & wmask) | (int_spike_buf[31:0] & ~wmask);
    end
end

// int_spike_buf[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_spike_buf[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SPIKE_BUF_DATA_1)
            int_spike_buf[63:32] <= (WDATA[31:0] & wmask) | (int_spike_buf[63:32] & ~wmask);
    end
end

// int_tmp_acc[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_tmp_acc[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_TMP_ACC_DATA_0)
            int_tmp_acc[31:0] <= (WDATA[31:0] & wmask) | (int_tmp_acc[31:0] & ~wmask);
    end
end

// int_tmp_acc[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_tmp_acc[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_TMP_ACC_DATA_1)
            int_tmp_acc[63:32] <= (WDATA[31:0] & wmask) | (int_tmp_acc[63:32] & ~wmask);
    end
end


//------------------------Memory logic-------------------

endmodule
