// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsa_tiny_fpga_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSa_tiny_fpga_top_CfgInitialize(XSa_tiny_fpga_top *InstancePtr, XSa_tiny_fpga_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSa_tiny_fpga_top_Start(XSa_tiny_fpga_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_tiny_fpga_top_ReadReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSa_tiny_fpga_top_WriteReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSa_tiny_fpga_top_IsDone(XSa_tiny_fpga_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_tiny_fpga_top_ReadReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSa_tiny_fpga_top_IsIdle(XSa_tiny_fpga_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_tiny_fpga_top_ReadReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSa_tiny_fpga_top_IsReady(XSa_tiny_fpga_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSa_tiny_fpga_top_ReadReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSa_tiny_fpga_top_EnableAutoRestart(XSa_tiny_fpga_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_tiny_fpga_top_WriteReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSa_tiny_fpga_top_DisableAutoRestart(XSa_tiny_fpga_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_tiny_fpga_top_WriteReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

void XSa_tiny_fpga_top_InterruptGlobalEnable(XSa_tiny_fpga_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_tiny_fpga_top_WriteReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_GIE, 1);
}

void XSa_tiny_fpga_top_InterruptGlobalDisable(XSa_tiny_fpga_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_tiny_fpga_top_WriteReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_GIE, 0);
}

void XSa_tiny_fpga_top_InterruptEnable(XSa_tiny_fpga_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_tiny_fpga_top_ReadReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_IER);
    XSa_tiny_fpga_top_WriteReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XSa_tiny_fpga_top_InterruptDisable(XSa_tiny_fpga_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSa_tiny_fpga_top_ReadReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_IER);
    XSa_tiny_fpga_top_WriteReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSa_tiny_fpga_top_InterruptClear(XSa_tiny_fpga_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSa_tiny_fpga_top_WriteReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XSa_tiny_fpga_top_InterruptGetEnabled(XSa_tiny_fpga_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_tiny_fpga_top_ReadReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_IER);
}

u32 XSa_tiny_fpga_top_InterruptGetStatus(XSa_tiny_fpga_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSa_tiny_fpga_top_ReadReg(InstancePtr->Control_BaseAddress, XSA_TINY_FPGA_TOP_CONTROL_ADDR_ISR);
}

