// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSA_TINY_FPGA_TOP_H
#define XSA_TINY_FPGA_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsa_tiny_fpga_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XSa_tiny_fpga_top_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XSa_tiny_fpga_top;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSa_tiny_fpga_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSa_tiny_fpga_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSa_tiny_fpga_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSa_tiny_fpga_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XSa_tiny_fpga_top_Initialize(XSa_tiny_fpga_top *InstancePtr, UINTPTR BaseAddress);
XSa_tiny_fpga_top_Config* XSa_tiny_fpga_top_LookupConfig(UINTPTR BaseAddress);
#else
int XSa_tiny_fpga_top_Initialize(XSa_tiny_fpga_top *InstancePtr, u16 DeviceId);
XSa_tiny_fpga_top_Config* XSa_tiny_fpga_top_LookupConfig(u16 DeviceId);
#endif
int XSa_tiny_fpga_top_CfgInitialize(XSa_tiny_fpga_top *InstancePtr, XSa_tiny_fpga_top_Config *ConfigPtr);
#else
int XSa_tiny_fpga_top_Initialize(XSa_tiny_fpga_top *InstancePtr, const char* InstanceName);
int XSa_tiny_fpga_top_Release(XSa_tiny_fpga_top *InstancePtr);
#endif

void XSa_tiny_fpga_top_Start(XSa_tiny_fpga_top *InstancePtr);
u32 XSa_tiny_fpga_top_IsDone(XSa_tiny_fpga_top *InstancePtr);
u32 XSa_tiny_fpga_top_IsIdle(XSa_tiny_fpga_top *InstancePtr);
u32 XSa_tiny_fpga_top_IsReady(XSa_tiny_fpga_top *InstancePtr);
void XSa_tiny_fpga_top_EnableAutoRestart(XSa_tiny_fpga_top *InstancePtr);
void XSa_tiny_fpga_top_DisableAutoRestart(XSa_tiny_fpga_top *InstancePtr);


void XSa_tiny_fpga_top_InterruptGlobalEnable(XSa_tiny_fpga_top *InstancePtr);
void XSa_tiny_fpga_top_InterruptGlobalDisable(XSa_tiny_fpga_top *InstancePtr);
void XSa_tiny_fpga_top_InterruptEnable(XSa_tiny_fpga_top *InstancePtr, u32 Mask);
void XSa_tiny_fpga_top_InterruptDisable(XSa_tiny_fpga_top *InstancePtr, u32 Mask);
void XSa_tiny_fpga_top_InterruptClear(XSa_tiny_fpga_top *InstancePtr, u32 Mask);
u32 XSa_tiny_fpga_top_InterruptGetEnabled(XSa_tiny_fpga_top *InstancePtr);
u32 XSa_tiny_fpga_top_InterruptGetStatus(XSa_tiny_fpga_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
