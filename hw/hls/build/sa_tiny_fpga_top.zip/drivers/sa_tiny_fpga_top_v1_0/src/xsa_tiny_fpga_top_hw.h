// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of layer_id
//        bit 31~0 - layer_id[31:0] (Read/Write)
// 0x14 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_TINY_FPGA_TOP_CONTROL_ADDR_AP_CTRL       0x00
#define XSA_TINY_FPGA_TOP_CONTROL_ADDR_GIE           0x04
#define XSA_TINY_FPGA_TOP_CONTROL_ADDR_IER           0x08
#define XSA_TINY_FPGA_TOP_CONTROL_ADDR_ISR           0x0c
#define XSA_TINY_FPGA_TOP_CONTROL_ADDR_LAYER_ID_DATA 0x10
#define XSA_TINY_FPGA_TOP_CONTROL_BITS_LAYER_ID_DATA 32

// control_r
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of img_in
//        bit 31~0 - img_in[31:0] (Read/Write)
// 0x14 : Data signal of img_in
//        bit 31~0 - img_in[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of feat_out
//        bit 31~0 - feat_out[31:0] (Read/Write)
// 0x20 : Data signal of feat_out
//        bit 31~0 - feat_out[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of w_pool
//        bit 31~0 - w_pool[31:0] (Read/Write)
// 0x2c : Data signal of w_pool
//        bit 31~0 - w_pool[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of bias_pool
//        bit 31~0 - bias_pool[31:0] (Read/Write)
// 0x38 : Data signal of bias_pool
//        bit 31~0 - bias_pool[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of shift_pool
//        bit 31~0 - shift_pool[31:0] (Read/Write)
// 0x44 : Data signal of shift_pool
//        bit 31~0 - shift_pool[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of scratch_a
//        bit 31~0 - scratch_a[31:0] (Read/Write)
// 0x50 : Data signal of scratch_a
//        bit 31~0 - scratch_a[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of scratch_b
//        bit 31~0 - scratch_b[31:0] (Read/Write)
// 0x5c : Data signal of scratch_b
//        bit 31~0 - scratch_b[63:32] (Read/Write)
// 0x60 : reserved
// 0x64 : Data signal of scratch_c
//        bit 31~0 - scratch_c[31:0] (Read/Write)
// 0x68 : Data signal of scratch_c
//        bit 31~0 - scratch_c[63:32] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of scratch_d
//        bit 31~0 - scratch_d[31:0] (Read/Write)
// 0x74 : Data signal of scratch_d
//        bit 31~0 - scratch_d[63:32] (Read/Write)
// 0x78 : reserved
// 0x7c : Data signal of scratch_e
//        bit 31~0 - scratch_e[31:0] (Read/Write)
// 0x80 : Data signal of scratch_e
//        bit 31~0 - scratch_e[63:32] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of scratch_f
//        bit 31~0 - scratch_f[31:0] (Read/Write)
// 0x8c : Data signal of scratch_f
//        bit 31~0 - scratch_f[63:32] (Read/Write)
// 0x90 : reserved
// 0x94 : Data signal of scratch_spike
//        bit 31~0 - scratch_spike[31:0] (Read/Write)
// 0x98 : Data signal of scratch_spike
//        bit 31~0 - scratch_spike[63:32] (Read/Write)
// 0x9c : reserved
// 0xa0 : Data signal of scratch_acc
//        bit 31~0 - scratch_acc[31:0] (Read/Write)
// 0xa4 : Data signal of scratch_acc
//        bit 31~0 - scratch_acc[63:32] (Read/Write)
// 0xa8 : reserved
// 0xac : Data signal of scratch_spk_a
//        bit 31~0 - scratch_spk_a[31:0] (Read/Write)
// 0xb0 : Data signal of scratch_spk_a
//        bit 31~0 - scratch_spk_a[63:32] (Read/Write)
// 0xb4 : reserved
// 0xb8 : Data signal of scratch_spk_b
//        bit 31~0 - scratch_spk_b[31:0] (Read/Write)
// 0xbc : Data signal of scratch_spk_b
//        bit 31~0 - scratch_spk_b[63:32] (Read/Write)
// 0xc0 : reserved
// 0xc4 : Data signal of scratch_spk_c
//        bit 31~0 - scratch_spk_c[31:0] (Read/Write)
// 0xc8 : Data signal of scratch_spk_c
//        bit 31~0 - scratch_spk_c[63:32] (Read/Write)
// 0xcc : reserved
// 0xd0 : Data signal of scratch_spk_d
//        bit 31~0 - scratch_spk_d[31:0] (Read/Write)
// 0xd4 : Data signal of scratch_spk_d
//        bit 31~0 - scratch_spk_d[63:32] (Read/Write)
// 0xd8 : reserved
// 0xdc : Data signal of scratch_spk_e
//        bit 31~0 - scratch_spk_e[31:0] (Read/Write)
// 0xe0 : Data signal of scratch_spk_e
//        bit 31~0 - scratch_spk_e[63:32] (Read/Write)
// 0xe4 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_IMG_IN_DATA        0x10
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_IMG_IN_DATA        64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_FEAT_OUT_DATA      0x1c
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_FEAT_OUT_DATA      64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_W_POOL_DATA        0x28
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_W_POOL_DATA        64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_BIAS_POOL_DATA     0x34
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_BIAS_POOL_DATA     64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SHIFT_POOL_DATA    0x40
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SHIFT_POOL_DATA    64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_A_DATA     0x4c
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_A_DATA     64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_B_DATA     0x58
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_B_DATA     64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_C_DATA     0x64
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_C_DATA     64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_D_DATA     0x70
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_D_DATA     64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_E_DATA     0x7c
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_E_DATA     64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_F_DATA     0x88
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_F_DATA     64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_SPIKE_DATA 0x94
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_SPIKE_DATA 64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_ACC_DATA   0xa0
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_ACC_DATA   64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_SPK_A_DATA 0xac
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_SPK_A_DATA 64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_SPK_B_DATA 0xb8
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_SPK_B_DATA 64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_SPK_C_DATA 0xc4
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_SPK_C_DATA 64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_SPK_D_DATA 0xd0
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_SPK_D_DATA 64
#define XSA_TINY_FPGA_TOP_CONTROL_R_ADDR_SCRATCH_SPK_E_DATA 0xdc
#define XSA_TINY_FPGA_TOP_CONTROL_R_BITS_SCRATCH_SPK_E_DATA 64

