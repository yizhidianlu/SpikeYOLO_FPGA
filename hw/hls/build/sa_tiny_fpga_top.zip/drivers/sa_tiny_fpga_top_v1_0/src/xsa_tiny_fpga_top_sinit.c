// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xsa_tiny_fpga_top.h"

extern XSa_tiny_fpga_top_Config XSa_tiny_fpga_top_ConfigTable[];

#ifdef SDT
XSa_tiny_fpga_top_Config *XSa_tiny_fpga_top_LookupConfig(UINTPTR BaseAddress) {
	XSa_tiny_fpga_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XSa_tiny_fpga_top_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XSa_tiny_fpga_top_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XSa_tiny_fpga_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSa_tiny_fpga_top_Initialize(XSa_tiny_fpga_top *InstancePtr, UINTPTR BaseAddress) {
	XSa_tiny_fpga_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSa_tiny_fpga_top_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSa_tiny_fpga_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XSa_tiny_fpga_top_Config *XSa_tiny_fpga_top_LookupConfig(u16 DeviceId) {
	XSa_tiny_fpga_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSA_TINY_FPGA_TOP_NUM_INSTANCES; Index++) {
		if (XSa_tiny_fpga_top_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSa_tiny_fpga_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSa_tiny_fpga_top_Initialize(XSa_tiny_fpga_top *InstancePtr, u16 DeviceId) {
	XSa_tiny_fpga_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSa_tiny_fpga_top_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSa_tiny_fpga_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

