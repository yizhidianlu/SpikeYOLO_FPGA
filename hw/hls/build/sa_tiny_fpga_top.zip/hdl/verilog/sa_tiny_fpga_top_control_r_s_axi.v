// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module sa_tiny_fpga_top_control_r_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 8,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire [63:0]                   img_in,
    output wire [63:0]                   feat_out,
    output wire [63:0]                   w_pool,
    output wire [63:0]                   bias_pool,
    output wire [63:0]                   shift_pool,
    output wire [63:0]                   scratch_a,
    output wire [63:0]                   scratch_b,
    output wire [63:0]                   scratch_c,
    output wire [63:0]                   scratch_d,
    output wire [63:0]                   scratch_e,
    output wire [63:0]                   scratch_f,
    output wire [63:0]                   scratch_spike,
    output wire [63:0]                   scratch_acc,
    output wire [63:0]                   scratch_spk_a,
    output wire [63:0]                   scratch_spk_b,
    output wire [63:0]                   scratch_spk_c,
    output wire [63:0]                   scratch_spk_d,
    output wire [63:0]                   scratch_spk_e
);
//------------------------Address Info-------------------
// Protocol Used: ap_ctrl_none
//
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of img_in
//        bit 31~0 - img_in[31:0] (Read/Write)
// 0x14 : Data signal of img_in
//        bit 31~0 - img_in[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of feat_out
//        bit 31~0 - feat_out[31:0] (Read/Write)
// 0x20 : Data signal of feat_out
//        bit 31~0 - feat_out[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of w_pool
//        bit 31~0 - w_pool[31:0] (Read/Write)
// 0x2c : Data signal of w_pool
//        bit 31~0 - w_pool[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of bias_pool
//        bit 31~0 - bias_pool[31:0] (Read/Write)
// 0x38 : Data signal of bias_pool
//        bit 31~0 - bias_pool[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of shift_pool
//        bit 31~0 - shift_pool[31:0] (Read/Write)
// 0x44 : Data signal of shift_pool
//        bit 31~0 - shift_pool[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of scratch_a
//        bit 31~0 - scratch_a[31:0] (Read/Write)
// 0x50 : Data signal of scratch_a
//        bit 31~0 - scratch_a[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of scratch_b
//        bit 31~0 - scratch_b[31:0] (Read/Write)
// 0x5c : Data signal of scratch_b
//        bit 31~0 - scratch_b[63:32] (Read/Write)
// 0x60 : reserved
// 0x64 : Data signal of scratch_c
//        bit 31~0 - scratch_c[31:0] (Read/Write)
// 0x68 : Data signal of scratch_c
//        bit 31~0 - scratch_c[63:32] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of scratch_d
//        bit 31~0 - scratch_d[31:0] (Read/Write)
// 0x74 : Data signal of scratch_d
//        bit 31~0 - scratch_d[63:32] (Read/Write)
// 0x78 : reserved
// 0x7c : Data signal of scratch_e
//        bit 31~0 - scratch_e[31:0] (Read/Write)
// 0x80 : Data signal of scratch_e
//        bit 31~0 - scratch_e[63:32] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of scratch_f
//        bit 31~0 - scratch_f[31:0] (Read/Write)
// 0x8c : Data signal of scratch_f
//        bit 31~0 - scratch_f[63:32] (Read/Write)
// 0x90 : reserved
// 0x94 : Data signal of scratch_spike
//        bit 31~0 - scratch_spike[31:0] (Read/Write)
// 0x98 : Data signal of scratch_spike
//        bit 31~0 - scratch_spike[63:32] (Read/Write)
// 0x9c : reserved
// 0xa0 : Data signal of scratch_acc
//        bit 31~0 - scratch_acc[31:0] (Read/Write)
// 0xa4 : Data signal of scratch_acc
//        bit 31~0 - scratch_acc[63:32] (Read/Write)
// 0xa8 : reserved
// 0xac : Data signal of scratch_spk_a
//        bit 31~0 - scratch_spk_a[31:0] (Read/Write)
// 0xb0 : Data signal of scratch_spk_a
//        bit 31~0 - scratch_spk_a[63:32] (Read/Write)
// 0xb4 : reserved
// 0xb8 : Data signal of scratch_spk_b
//        bit 31~0 - scratch_spk_b[31:0] (Read/Write)
// 0xbc : Data signal of scratch_spk_b
//        bit 31~0 - scratch_spk_b[63:32] (Read/Write)
// 0xc0 : reserved
// 0xc4 : Data signal of scratch_spk_c
//        bit 31~0 - scratch_spk_c[31:0] (Read/Write)
// 0xc8 : Data signal of scratch_spk_c
//        bit 31~0 - scratch_spk_c[63:32] (Read/Write)
// 0xcc : reserved
// 0xd0 : Data signal of scratch_spk_d
//        bit 31~0 - scratch_spk_d[31:0] (Read/Write)
// 0xd4 : Data signal of scratch_spk_d
//        bit 31~0 - scratch_spk_d[63:32] (Read/Write)
// 0xd8 : reserved
// 0xdc : Data signal of scratch_spk_e
//        bit 31~0 - scratch_spk_e[31:0] (Read/Write)
// 0xe0 : Data signal of scratch_spk_e
//        bit 31~0 - scratch_spk_e[63:32] (Read/Write)
// 0xe4 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_IMG_IN_DATA_0        = 8'h10,
    ADDR_IMG_IN_DATA_1        = 8'h14,
    ADDR_IMG_IN_CTRL          = 8'h18,
    ADDR_FEAT_OUT_DATA_0      = 8'h1c,
    ADDR_FEAT_OUT_DATA_1      = 8'h20,
    ADDR_FEAT_OUT_CTRL        = 8'h24,
    ADDR_W_POOL_DATA_0        = 8'h28,
    ADDR_W_POOL_DATA_1        = 8'h2c,
    ADDR_W_POOL_CTRL          = 8'h30,
    ADDR_BIAS_POOL_DATA_0     = 8'h34,
    ADDR_BIAS_POOL_DATA_1     = 8'h38,
    ADDR_BIAS_POOL_CTRL       = 8'h3c,
    ADDR_SHIFT_POOL_DATA_0    = 8'h40,
    ADDR_SHIFT_POOL_DATA_1    = 8'h44,
    ADDR_SHIFT_POOL_CTRL      = 8'h48,
    ADDR_SCRATCH_A_DATA_0     = 8'h4c,
    ADDR_SCRATCH_A_DATA_1     = 8'h50,
    ADDR_SCRATCH_A_CTRL       = 8'h54,
    ADDR_SCRATCH_B_DATA_0     = 8'h58,
    ADDR_SCRATCH_B_DATA_1     = 8'h5c,
    ADDR_SCRATCH_B_CTRL       = 8'h60,
    ADDR_SCRATCH_C_DATA_0     = 8'h64,
    ADDR_SCRATCH_C_DATA_1     = 8'h68,
    ADDR_SCRATCH_C_CTRL       = 8'h6c,
    ADDR_SCRATCH_D_DATA_0     = 8'h70,
    ADDR_SCRATCH_D_DATA_1     = 8'h74,
    ADDR_SCRATCH_D_CTRL       = 8'h78,
    ADDR_SCRATCH_E_DATA_0     = 8'h7c,
    ADDR_SCRATCH_E_DATA_1     = 8'h80,
    ADDR_SCRATCH_E_CTRL       = 8'h84,
    ADDR_SCRATCH_F_DATA_0     = 8'h88,
    ADDR_SCRATCH_F_DATA_1     = 8'h8c,
    ADDR_SCRATCH_F_CTRL       = 8'h90,
    ADDR_SCRATCH_SPIKE_DATA_0 = 8'h94,
    ADDR_SCRATCH_SPIKE_DATA_1 = 8'h98,
    ADDR_SCRATCH_SPIKE_CTRL   = 8'h9c,
    ADDR_SCRATCH_ACC_DATA_0   = 8'ha0,
    ADDR_SCRATCH_ACC_DATA_1   = 8'ha4,
    ADDR_SCRATCH_ACC_CTRL     = 8'ha8,
    ADDR_SCRATCH_SPK_A_DATA_0 = 8'hac,
    ADDR_SCRATCH_SPK_A_DATA_1 = 8'hb0,
    ADDR_SCRATCH_SPK_A_CTRL   = 8'hb4,
    ADDR_SCRATCH_SPK_B_DATA_0 = 8'hb8,
    ADDR_SCRATCH_SPK_B_DATA_1 = 8'hbc,
    ADDR_SCRATCH_SPK_B_CTRL   = 8'hc0,
    ADDR_SCRATCH_SPK_C_DATA_0 = 8'hc4,
    ADDR_SCRATCH_SPK_C_DATA_1 = 8'hc8,
    ADDR_SCRATCH_SPK_C_CTRL   = 8'hcc,
    ADDR_SCRATCH_SPK_D_DATA_0 = 8'hd0,
    ADDR_SCRATCH_SPK_D_DATA_1 = 8'hd4,
    ADDR_SCRATCH_SPK_D_CTRL   = 8'hd8,
    ADDR_SCRATCH_SPK_E_DATA_0 = 8'hdc,
    ADDR_SCRATCH_SPK_E_DATA_1 = 8'he0,
    ADDR_SCRATCH_SPK_E_CTRL   = 8'he4,
    WRIDLE                    = 2'd0,
    WRDATA                    = 2'd1,
    WRRESP                    = 2'd2,
    WRRESET                   = 2'd3,
    RDIDLE                    = 2'd0,
    RDDATA                    = 2'd1,
    RDRESET                   = 2'd2,
    ADDR_BITS                = 8;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg  [63:0]                   int_img_in = 'b0;
    reg  [63:0]                   int_feat_out = 'b0;
    reg  [63:0]                   int_w_pool = 'b0;
    reg  [63:0]                   int_bias_pool = 'b0;
    reg  [63:0]                   int_shift_pool = 'b0;
    reg  [63:0]                   int_scratch_a = 'b0;
    reg  [63:0]                   int_scratch_b = 'b0;
    reg  [63:0]                   int_scratch_c = 'b0;
    reg  [63:0]                   int_scratch_d = 'b0;
    reg  [63:0]                   int_scratch_e = 'b0;
    reg  [63:0]                   int_scratch_f = 'b0;
    reg  [63:0]                   int_scratch_spike = 'b0;
    reg  [63:0]                   int_scratch_acc = 'b0;
    reg  [63:0]                   int_scratch_spk_a = 'b0;
    reg  [63:0]                   int_scratch_spk_b = 'b0;
    reg  [63:0]                   int_scratch_spk_c = 'b0;
    reg  [63:0]                   int_scratch_spk_d = 'b0;
    reg  [63:0]                   int_scratch_spk_e = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BRESP   = 2'b00;  // OKAY
assign BVALID  = (wstate == WRRESP);
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= {AWADDR[ADDR_BITS-1:2], {2{1'b0}}};
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_IMG_IN_DATA_0: begin
                    rdata <= int_img_in[31:0];
                end
                ADDR_IMG_IN_DATA_1: begin
                    rdata <= int_img_in[63:32];
                end
                ADDR_FEAT_OUT_DATA_0: begin
                    rdata <= int_feat_out[31:0];
                end
                ADDR_FEAT_OUT_DATA_1: begin
                    rdata <= int_feat_out[63:32];
                end
                ADDR_W_POOL_DATA_0: begin
                    rdata <= int_w_pool[31:0];
                end
                ADDR_W_POOL_DATA_1: begin
                    rdata <= int_w_pool[63:32];
                end
                ADDR_BIAS_POOL_DATA_0: begin
                    rdata <= int_bias_pool[31:0];
                end
                ADDR_BIAS_POOL_DATA_1: begin
                    rdata <= int_bias_pool[63:32];
                end
                ADDR_SHIFT_POOL_DATA_0: begin
                    rdata <= int_shift_pool[31:0];
                end
                ADDR_SHIFT_POOL_DATA_1: begin
                    rdata <= int_shift_pool[63:32];
                end
                ADDR_SCRATCH_A_DATA_0: begin
                    rdata <= int_scratch_a[31:0];
                end
                ADDR_SCRATCH_A_DATA_1: begin
                    rdata <= int_scratch_a[63:32];
                end
                ADDR_SCRATCH_B_DATA_0: begin
                    rdata <= int_scratch_b[31:0];
                end
                ADDR_SCRATCH_B_DATA_1: begin
                    rdata <= int_scratch_b[63:32];
                end
                ADDR_SCRATCH_C_DATA_0: begin
                    rdata <= int_scratch_c[31:0];
                end
                ADDR_SCRATCH_C_DATA_1: begin
                    rdata <= int_scratch_c[63:32];
                end
                ADDR_SCRATCH_D_DATA_0: begin
                    rdata <= int_scratch_d[31:0];
                end
                ADDR_SCRATCH_D_DATA_1: begin
                    rdata <= int_scratch_d[63:32];
                end
                ADDR_SCRATCH_E_DATA_0: begin
                    rdata <= int_scratch_e[31:0];
                end
                ADDR_SCRATCH_E_DATA_1: begin
                    rdata <= int_scratch_e[63:32];
                end
                ADDR_SCRATCH_F_DATA_0: begin
                    rdata <= int_scratch_f[31:0];
                end
                ADDR_SCRATCH_F_DATA_1: begin
                    rdata <= int_scratch_f[63:32];
                end
                ADDR_SCRATCH_SPIKE_DATA_0: begin
                    rdata <= int_scratch_spike[31:0];
                end
                ADDR_SCRATCH_SPIKE_DATA_1: begin
                    rdata <= int_scratch_spike[63:32];
                end
                ADDR_SCRATCH_ACC_DATA_0: begin
                    rdata <= int_scratch_acc[31:0];
                end
                ADDR_SCRATCH_ACC_DATA_1: begin
                    rdata <= int_scratch_acc[63:32];
                end
                ADDR_SCRATCH_SPK_A_DATA_0: begin
                    rdata <= int_scratch_spk_a[31:0];
                end
                ADDR_SCRATCH_SPK_A_DATA_1: begin
                    rdata <= int_scratch_spk_a[63:32];
                end
                ADDR_SCRATCH_SPK_B_DATA_0: begin
                    rdata <= int_scratch_spk_b[31:0];
                end
                ADDR_SCRATCH_SPK_B_DATA_1: begin
                    rdata <= int_scratch_spk_b[63:32];
                end
                ADDR_SCRATCH_SPK_C_DATA_0: begin
                    rdata <= int_scratch_spk_c[31:0];
                end
                ADDR_SCRATCH_SPK_C_DATA_1: begin
                    rdata <= int_scratch_spk_c[63:32];
                end
                ADDR_SCRATCH_SPK_D_DATA_0: begin
                    rdata <= int_scratch_spk_d[31:0];
                end
                ADDR_SCRATCH_SPK_D_DATA_1: begin
                    rdata <= int_scratch_spk_d[63:32];
                end
                ADDR_SCRATCH_SPK_E_DATA_0: begin
                    rdata <= int_scratch_spk_e[31:0];
                end
                ADDR_SCRATCH_SPK_E_DATA_1: begin
                    rdata <= int_scratch_spk_e[63:32];
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign img_in        = int_img_in;
assign feat_out      = int_feat_out;
assign w_pool        = int_w_pool;
assign bias_pool     = int_bias_pool;
assign shift_pool    = int_shift_pool;
assign scratch_a     = int_scratch_a;
assign scratch_b     = int_scratch_b;
assign scratch_c     = int_scratch_c;
assign scratch_d     = int_scratch_d;
assign scratch_e     = int_scratch_e;
assign scratch_f     = int_scratch_f;
assign scratch_spike = int_scratch_spike;
assign scratch_acc   = int_scratch_acc;
assign scratch_spk_a = int_scratch_spk_a;
assign scratch_spk_b = int_scratch_spk_b;
assign scratch_spk_c = int_scratch_spk_c;
assign scratch_spk_d = int_scratch_spk_d;
assign scratch_spk_e = int_scratch_spk_e;
// int_img_in[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_img_in[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_IMG_IN_DATA_0)
            int_img_in[31:0] <= (WDATA[31:0] & wmask) | (int_img_in[31:0] & ~wmask);
    end
end

// int_img_in[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_img_in[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_IMG_IN_DATA_1)
            int_img_in[63:32] <= (WDATA[31:0] & wmask) | (int_img_in[63:32] & ~wmask);
    end
end

// int_feat_out[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_feat_out[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_FEAT_OUT_DATA_0)
            int_feat_out[31:0] <= (WDATA[31:0] & wmask) | (int_feat_out[31:0] & ~wmask);
    end
end

// int_feat_out[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_feat_out[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_FEAT_OUT_DATA_1)
            int_feat_out[63:32] <= (WDATA[31:0] & wmask) | (int_feat_out[63:32] & ~wmask);
    end
end

// int_w_pool[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_w_pool[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_W_POOL_DATA_0)
            int_w_pool[31:0] <= (WDATA[31:0] & wmask) | (int_w_pool[31:0] & ~wmask);
    end
end

// int_w_pool[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_w_pool[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_W_POOL_DATA_1)
            int_w_pool[63:32] <= (WDATA[31:0] & wmask) | (int_w_pool[63:32] & ~wmask);
    end
end

// int_bias_pool[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_bias_pool[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_BIAS_POOL_DATA_0)
            int_bias_pool[31:0] <= (WDATA[31:0] & wmask) | (int_bias_pool[31:0] & ~wmask);
    end
end

// int_bias_pool[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_bias_pool[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_BIAS_POOL_DATA_1)
            int_bias_pool[63:32] <= (WDATA[31:0] & wmask) | (int_bias_pool[63:32] & ~wmask);
    end
end

// int_shift_pool[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_shift_pool[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SHIFT_POOL_DATA_0)
            int_shift_pool[31:0] <= (WDATA[31:0] & wmask) | (int_shift_pool[31:0] & ~wmask);
    end
end

// int_shift_pool[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_shift_pool[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SHIFT_POOL_DATA_1)
            int_shift_pool[63:32] <= (WDATA[31:0] & wmask) | (int_shift_pool[63:32] & ~wmask);
    end
end

// int_scratch_a[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_a[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_A_DATA_0)
            int_scratch_a[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_a[31:0] & ~wmask);
    end
end

// int_scratch_a[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_a[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_A_DATA_1)
            int_scratch_a[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_a[63:32] & ~wmask);
    end
end

// int_scratch_b[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_b[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_B_DATA_0)
            int_scratch_b[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_b[31:0] & ~wmask);
    end
end

// int_scratch_b[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_b[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_B_DATA_1)
            int_scratch_b[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_b[63:32] & ~wmask);
    end
end

// int_scratch_c[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_c[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_C_DATA_0)
            int_scratch_c[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_c[31:0] & ~wmask);
    end
end

// int_scratch_c[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_c[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_C_DATA_1)
            int_scratch_c[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_c[63:32] & ~wmask);
    end
end

// int_scratch_d[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_d[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_D_DATA_0)
            int_scratch_d[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_d[31:0] & ~wmask);
    end
end

// int_scratch_d[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_d[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_D_DATA_1)
            int_scratch_d[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_d[63:32] & ~wmask);
    end
end

// int_scratch_e[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_e[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_E_DATA_0)
            int_scratch_e[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_e[31:0] & ~wmask);
    end
end

// int_scratch_e[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_e[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_E_DATA_1)
            int_scratch_e[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_e[63:32] & ~wmask);
    end
end

// int_scratch_f[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_f[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_F_DATA_0)
            int_scratch_f[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_f[31:0] & ~wmask);
    end
end

// int_scratch_f[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_f[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_F_DATA_1)
            int_scratch_f[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_f[63:32] & ~wmask);
    end
end

// int_scratch_spike[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spike[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPIKE_DATA_0)
            int_scratch_spike[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_spike[31:0] & ~wmask);
    end
end

// int_scratch_spike[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spike[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPIKE_DATA_1)
            int_scratch_spike[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_spike[63:32] & ~wmask);
    end
end

// int_scratch_acc[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_acc[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_ACC_DATA_0)
            int_scratch_acc[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_acc[31:0] & ~wmask);
    end
end

// int_scratch_acc[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_acc[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_ACC_DATA_1)
            int_scratch_acc[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_acc[63:32] & ~wmask);
    end
end

// int_scratch_spk_a[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_a[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_A_DATA_0)
            int_scratch_spk_a[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_spk_a[31:0] & ~wmask);
    end
end

// int_scratch_spk_a[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_a[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_A_DATA_1)
            int_scratch_spk_a[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_spk_a[63:32] & ~wmask);
    end
end

// int_scratch_spk_b[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_b[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_B_DATA_0)
            int_scratch_spk_b[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_spk_b[31:0] & ~wmask);
    end
end

// int_scratch_spk_b[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_b[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_B_DATA_1)
            int_scratch_spk_b[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_spk_b[63:32] & ~wmask);
    end
end

// int_scratch_spk_c[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_c[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_C_DATA_0)
            int_scratch_spk_c[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_spk_c[31:0] & ~wmask);
    end
end

// int_scratch_spk_c[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_c[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_C_DATA_1)
            int_scratch_spk_c[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_spk_c[63:32] & ~wmask);
    end
end

// int_scratch_spk_d[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_d[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_D_DATA_0)
            int_scratch_spk_d[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_spk_d[31:0] & ~wmask);
    end
end

// int_scratch_spk_d[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_d[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_D_DATA_1)
            int_scratch_spk_d[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_spk_d[63:32] & ~wmask);
    end
end

// int_scratch_spk_e[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_e[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_E_DATA_0)
            int_scratch_spk_e[31:0] <= (WDATA[31:0] & wmask) | (int_scratch_spk_e[31:0] & ~wmask);
    end
end

// int_scratch_spk_e[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_scratch_spk_e[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SCRATCH_SPK_E_DATA_1)
            int_scratch_spk_e[63:32] <= (WDATA[31:0] & wmask) | (int_scratch_spk_e[63:32] & ~wmask);
    end
end


//------------------------Memory logic-------------------

endmodule
