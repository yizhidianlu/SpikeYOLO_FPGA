-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
-- Tool Version Limit: 2024.05
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- 
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity sa_tiny_fpga_top_control_r_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 8;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    img_in                :out  STD_LOGIC_VECTOR(63 downto 0);
    feat_out              :out  STD_LOGIC_VECTOR(63 downto 0);
    w_pool                :out  STD_LOGIC_VECTOR(63 downto 0);
    bias_pool             :out  STD_LOGIC_VECTOR(63 downto 0);
    shift_pool            :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_a             :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_b             :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_c             :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_d             :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_e             :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_f             :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_spike         :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_acc           :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_spk_a         :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_spk_b         :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_spk_c         :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_spk_d         :out  STD_LOGIC_VECTOR(63 downto 0);
    scratch_spk_e         :out  STD_LOGIC_VECTOR(63 downto 0)
);
end entity sa_tiny_fpga_top_control_r_s_axi;

-- ------------------------Address Info-------------------
-- Protocol Used: ap_ctrl_none
--
-- 0x00 : reserved
-- 0x04 : reserved
-- 0x08 : reserved
-- 0x0c : reserved
-- 0x10 : Data signal of img_in
--        bit 31~0 - img_in[31:0] (Read/Write)
-- 0x14 : Data signal of img_in
--        bit 31~0 - img_in[63:32] (Read/Write)
-- 0x18 : reserved
-- 0x1c : Data signal of feat_out
--        bit 31~0 - feat_out[31:0] (Read/Write)
-- 0x20 : Data signal of feat_out
--        bit 31~0 - feat_out[63:32] (Read/Write)
-- 0x24 : reserved
-- 0x28 : Data signal of w_pool
--        bit 31~0 - w_pool[31:0] (Read/Write)
-- 0x2c : Data signal of w_pool
--        bit 31~0 - w_pool[63:32] (Read/Write)
-- 0x30 : reserved
-- 0x34 : Data signal of bias_pool
--        bit 31~0 - bias_pool[31:0] (Read/Write)
-- 0x38 : Data signal of bias_pool
--        bit 31~0 - bias_pool[63:32] (Read/Write)
-- 0x3c : reserved
-- 0x40 : Data signal of shift_pool
--        bit 31~0 - shift_pool[31:0] (Read/Write)
-- 0x44 : Data signal of shift_pool
--        bit 31~0 - shift_pool[63:32] (Read/Write)
-- 0x48 : reserved
-- 0x4c : Data signal of scratch_a
--        bit 31~0 - scratch_a[31:0] (Read/Write)
-- 0x50 : Data signal of scratch_a
--        bit 31~0 - scratch_a[63:32] (Read/Write)
-- 0x54 : reserved
-- 0x58 : Data signal of scratch_b
--        bit 31~0 - scratch_b[31:0] (Read/Write)
-- 0x5c : Data signal of scratch_b
--        bit 31~0 - scratch_b[63:32] (Read/Write)
-- 0x60 : reserved
-- 0x64 : Data signal of scratch_c
--        bit 31~0 - scratch_c[31:0] (Read/Write)
-- 0x68 : Data signal of scratch_c
--        bit 31~0 - scratch_c[63:32] (Read/Write)
-- 0x6c : reserved
-- 0x70 : Data signal of scratch_d
--        bit 31~0 - scratch_d[31:0] (Read/Write)
-- 0x74 : Data signal of scratch_d
--        bit 31~0 - scratch_d[63:32] (Read/Write)
-- 0x78 : reserved
-- 0x7c : Data signal of scratch_e
--        bit 31~0 - scratch_e[31:0] (Read/Write)
-- 0x80 : Data signal of scratch_e
--        bit 31~0 - scratch_e[63:32] (Read/Write)
-- 0x84 : reserved
-- 0x88 : Data signal of scratch_f
--        bit 31~0 - scratch_f[31:0] (Read/Write)
-- 0x8c : Data signal of scratch_f
--        bit 31~0 - scratch_f[63:32] (Read/Write)
-- 0x90 : reserved
-- 0x94 : Data signal of scratch_spike
--        bit 31~0 - scratch_spike[31:0] (Read/Write)
-- 0x98 : Data signal of scratch_spike
--        bit 31~0 - scratch_spike[63:32] (Read/Write)
-- 0x9c : reserved
-- 0xa0 : Data signal of scratch_acc
--        bit 31~0 - scratch_acc[31:0] (Read/Write)
-- 0xa4 : Data signal of scratch_acc
--        bit 31~0 - scratch_acc[63:32] (Read/Write)
-- 0xa8 : reserved
-- 0xac : Data signal of scratch_spk_a
--        bit 31~0 - scratch_spk_a[31:0] (Read/Write)
-- 0xb0 : Data signal of scratch_spk_a
--        bit 31~0 - scratch_spk_a[63:32] (Read/Write)
-- 0xb4 : reserved
-- 0xb8 : Data signal of scratch_spk_b
--        bit 31~0 - scratch_spk_b[31:0] (Read/Write)
-- 0xbc : Data signal of scratch_spk_b
--        bit 31~0 - scratch_spk_b[63:32] (Read/Write)
-- 0xc0 : reserved
-- 0xc4 : Data signal of scratch_spk_c
--        bit 31~0 - scratch_spk_c[31:0] (Read/Write)
-- 0xc8 : Data signal of scratch_spk_c
--        bit 31~0 - scratch_spk_c[63:32] (Read/Write)
-- 0xcc : reserved
-- 0xd0 : Data signal of scratch_spk_d
--        bit 31~0 - scratch_spk_d[31:0] (Read/Write)
-- 0xd4 : Data signal of scratch_spk_d
--        bit 31~0 - scratch_spk_d[63:32] (Read/Write)
-- 0xd8 : reserved
-- 0xdc : Data signal of scratch_spk_e
--        bit 31~0 - scratch_spk_e[31:0] (Read/Write)
-- 0xe0 : Data signal of scratch_spk_e
--        bit 31~0 - scratch_spk_e[63:32] (Read/Write)
-- 0xe4 : reserved
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of sa_tiny_fpga_top_control_r_s_axi is
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_IMG_IN_DATA_0        : INTEGER := 16#10#;
    constant ADDR_IMG_IN_DATA_1        : INTEGER := 16#14#;
    constant ADDR_IMG_IN_CTRL          : INTEGER := 16#18#;
    constant ADDR_FEAT_OUT_DATA_0      : INTEGER := 16#1c#;
    constant ADDR_FEAT_OUT_DATA_1      : INTEGER := 16#20#;
    constant ADDR_FEAT_OUT_CTRL        : INTEGER := 16#24#;
    constant ADDR_W_POOL_DATA_0        : INTEGER := 16#28#;
    constant ADDR_W_POOL_DATA_1        : INTEGER := 16#2c#;
    constant ADDR_W_POOL_CTRL          : INTEGER := 16#30#;
    constant ADDR_BIAS_POOL_DATA_0     : INTEGER := 16#34#;
    constant ADDR_BIAS_POOL_DATA_1     : INTEGER := 16#38#;
    constant ADDR_BIAS_POOL_CTRL       : INTEGER := 16#3c#;
    constant ADDR_SHIFT_POOL_DATA_0    : INTEGER := 16#40#;
    constant ADDR_SHIFT_POOL_DATA_1    : INTEGER := 16#44#;
    constant ADDR_SHIFT_POOL_CTRL      : INTEGER := 16#48#;
    constant ADDR_SCRATCH_A_DATA_0     : INTEGER := 16#4c#;
    constant ADDR_SCRATCH_A_DATA_1     : INTEGER := 16#50#;
    constant ADDR_SCRATCH_A_CTRL       : INTEGER := 16#54#;
    constant ADDR_SCRATCH_B_DATA_0     : INTEGER := 16#58#;
    constant ADDR_SCRATCH_B_DATA_1     : INTEGER := 16#5c#;
    constant ADDR_SCRATCH_B_CTRL       : INTEGER := 16#60#;
    constant ADDR_SCRATCH_C_DATA_0     : INTEGER := 16#64#;
    constant ADDR_SCRATCH_C_DATA_1     : INTEGER := 16#68#;
    constant ADDR_SCRATCH_C_CTRL       : INTEGER := 16#6c#;
    constant ADDR_SCRATCH_D_DATA_0     : INTEGER := 16#70#;
    constant ADDR_SCRATCH_D_DATA_1     : INTEGER := 16#74#;
    constant ADDR_SCRATCH_D_CTRL       : INTEGER := 16#78#;
    constant ADDR_SCRATCH_E_DATA_0     : INTEGER := 16#7c#;
    constant ADDR_SCRATCH_E_DATA_1     : INTEGER := 16#80#;
    constant ADDR_SCRATCH_E_CTRL       : INTEGER := 16#84#;
    constant ADDR_SCRATCH_F_DATA_0     : INTEGER := 16#88#;
    constant ADDR_SCRATCH_F_DATA_1     : INTEGER := 16#8c#;
    constant ADDR_SCRATCH_F_CTRL       : INTEGER := 16#90#;
    constant ADDR_SCRATCH_SPIKE_DATA_0 : INTEGER := 16#94#;
    constant ADDR_SCRATCH_SPIKE_DATA_1 : INTEGER := 16#98#;
    constant ADDR_SCRATCH_SPIKE_CTRL   : INTEGER := 16#9c#;
    constant ADDR_SCRATCH_ACC_DATA_0   : INTEGER := 16#a0#;
    constant ADDR_SCRATCH_ACC_DATA_1   : INTEGER := 16#a4#;
    constant ADDR_SCRATCH_ACC_CTRL     : INTEGER := 16#a8#;
    constant ADDR_SCRATCH_SPK_A_DATA_0 : INTEGER := 16#ac#;
    constant ADDR_SCRATCH_SPK_A_DATA_1 : INTEGER := 16#b0#;
    constant ADDR_SCRATCH_SPK_A_CTRL   : INTEGER := 16#b4#;
    constant ADDR_SCRATCH_SPK_B_DATA_0 : INTEGER := 16#b8#;
    constant ADDR_SCRATCH_SPK_B_DATA_1 : INTEGER := 16#bc#;
    constant ADDR_SCRATCH_SPK_B_CTRL   : INTEGER := 16#c0#;
    constant ADDR_SCRATCH_SPK_C_DATA_0 : INTEGER := 16#c4#;
    constant ADDR_SCRATCH_SPK_C_DATA_1 : INTEGER := 16#c8#;
    constant ADDR_SCRATCH_SPK_C_CTRL   : INTEGER := 16#cc#;
    constant ADDR_SCRATCH_SPK_D_DATA_0 : INTEGER := 16#d0#;
    constant ADDR_SCRATCH_SPK_D_DATA_1 : INTEGER := 16#d4#;
    constant ADDR_SCRATCH_SPK_D_CTRL   : INTEGER := 16#d8#;
    constant ADDR_SCRATCH_SPK_E_DATA_0 : INTEGER := 16#dc#;
    constant ADDR_SCRATCH_SPK_E_DATA_1 : INTEGER := 16#e0#;
    constant ADDR_SCRATCH_SPK_E_CTRL   : INTEGER := 16#e4#;
    constant ADDR_BITS         : INTEGER := 8;

    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    -- internal registers
    signal int_img_in          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_feat_out        : UNSIGNED(63 downto 0) := (others => '0');
    signal int_w_pool          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_bias_pool       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_shift_pool      : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_a       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_b       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_c       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_d       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_e       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_f       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_spike   : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_acc     : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_spk_a   : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_spk_b   : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_spk_c   : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_spk_d   : UNSIGNED(63 downto 0) := (others => '0');
    signal int_scratch_spk_e   : UNSIGNED(63 downto 0) := (others => '0');


begin
-- ----------------------- Instantiation------------------


-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata else '0';
    WREADY    <=  WREADY_t;
    BRESP     <=  "00";  -- OKAY
    BVALID    <=  '1' when wstate = wrresp else '0';
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, WVALID, BREADY)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (WVALID = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 2) & (1 downto 0 => '0'));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    rdata_data <= (others => '0');
                    case (TO_INTEGER(raddr)) is
                    when ADDR_IMG_IN_DATA_0 =>
                        rdata_data <= RESIZE(int_img_in(31 downto 0), 32);
                    when ADDR_IMG_IN_DATA_1 =>
                        rdata_data <= RESIZE(int_img_in(63 downto 32), 32);
                    when ADDR_FEAT_OUT_DATA_0 =>
                        rdata_data <= RESIZE(int_feat_out(31 downto 0), 32);
                    when ADDR_FEAT_OUT_DATA_1 =>
                        rdata_data <= RESIZE(int_feat_out(63 downto 32), 32);
                    when ADDR_W_POOL_DATA_0 =>
                        rdata_data <= RESIZE(int_w_pool(31 downto 0), 32);
                    when ADDR_W_POOL_DATA_1 =>
                        rdata_data <= RESIZE(int_w_pool(63 downto 32), 32);
                    when ADDR_BIAS_POOL_DATA_0 =>
                        rdata_data <= RESIZE(int_bias_pool(31 downto 0), 32);
                    when ADDR_BIAS_POOL_DATA_1 =>
                        rdata_data <= RESIZE(int_bias_pool(63 downto 32), 32);
                    when ADDR_SHIFT_POOL_DATA_0 =>
                        rdata_data <= RESIZE(int_shift_pool(31 downto 0), 32);
                    when ADDR_SHIFT_POOL_DATA_1 =>
                        rdata_data <= RESIZE(int_shift_pool(63 downto 32), 32);
                    when ADDR_SCRATCH_A_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_a(31 downto 0), 32);
                    when ADDR_SCRATCH_A_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_a(63 downto 32), 32);
                    when ADDR_SCRATCH_B_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_b(31 downto 0), 32);
                    when ADDR_SCRATCH_B_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_b(63 downto 32), 32);
                    when ADDR_SCRATCH_C_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_c(31 downto 0), 32);
                    when ADDR_SCRATCH_C_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_c(63 downto 32), 32);
                    when ADDR_SCRATCH_D_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_d(31 downto 0), 32);
                    when ADDR_SCRATCH_D_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_d(63 downto 32), 32);
                    when ADDR_SCRATCH_E_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_e(31 downto 0), 32);
                    when ADDR_SCRATCH_E_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_e(63 downto 32), 32);
                    when ADDR_SCRATCH_F_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_f(31 downto 0), 32);
                    when ADDR_SCRATCH_F_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_f(63 downto 32), 32);
                    when ADDR_SCRATCH_SPIKE_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_spike(31 downto 0), 32);
                    when ADDR_SCRATCH_SPIKE_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_spike(63 downto 32), 32);
                    when ADDR_SCRATCH_ACC_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_acc(31 downto 0), 32);
                    when ADDR_SCRATCH_ACC_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_acc(63 downto 32), 32);
                    when ADDR_SCRATCH_SPK_A_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_spk_a(31 downto 0), 32);
                    when ADDR_SCRATCH_SPK_A_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_spk_a(63 downto 32), 32);
                    when ADDR_SCRATCH_SPK_B_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_spk_b(31 downto 0), 32);
                    when ADDR_SCRATCH_SPK_B_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_spk_b(63 downto 32), 32);
                    when ADDR_SCRATCH_SPK_C_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_spk_c(31 downto 0), 32);
                    when ADDR_SCRATCH_SPK_C_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_spk_c(63 downto 32), 32);
                    when ADDR_SCRATCH_SPK_D_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_spk_d(31 downto 0), 32);
                    when ADDR_SCRATCH_SPK_D_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_spk_d(63 downto 32), 32);
                    when ADDR_SCRATCH_SPK_E_DATA_0 =>
                        rdata_data <= RESIZE(int_scratch_spk_e(31 downto 0), 32);
                    when ADDR_SCRATCH_SPK_E_DATA_1 =>
                        rdata_data <= RESIZE(int_scratch_spk_e(63 downto 32), 32);
                    when others =>
                        NULL;
                    end case;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    img_in               <= STD_LOGIC_VECTOR(int_img_in);
    feat_out             <= STD_LOGIC_VECTOR(int_feat_out);
    w_pool               <= STD_LOGIC_VECTOR(int_w_pool);
    bias_pool            <= STD_LOGIC_VECTOR(int_bias_pool);
    shift_pool           <= STD_LOGIC_VECTOR(int_shift_pool);
    scratch_a            <= STD_LOGIC_VECTOR(int_scratch_a);
    scratch_b            <= STD_LOGIC_VECTOR(int_scratch_b);
    scratch_c            <= STD_LOGIC_VECTOR(int_scratch_c);
    scratch_d            <= STD_LOGIC_VECTOR(int_scratch_d);
    scratch_e            <= STD_LOGIC_VECTOR(int_scratch_e);
    scratch_f            <= STD_LOGIC_VECTOR(int_scratch_f);
    scratch_spike        <= STD_LOGIC_VECTOR(int_scratch_spike);
    scratch_acc          <= STD_LOGIC_VECTOR(int_scratch_acc);
    scratch_spk_a        <= STD_LOGIC_VECTOR(int_scratch_spk_a);
    scratch_spk_b        <= STD_LOGIC_VECTOR(int_scratch_spk_b);
    scratch_spk_c        <= STD_LOGIC_VECTOR(int_scratch_spk_c);
    scratch_spk_d        <= STD_LOGIC_VECTOR(int_scratch_spk_d);
    scratch_spk_e        <= STD_LOGIC_VECTOR(int_scratch_spk_e);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_img_in(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMG_IN_DATA_0) then
                    int_img_in(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_img_in(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_img_in(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMG_IN_DATA_1) then
                    int_img_in(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_img_in(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_feat_out(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_FEAT_OUT_DATA_0) then
                    int_feat_out(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_feat_out(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_feat_out(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_FEAT_OUT_DATA_1) then
                    int_feat_out(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_feat_out(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_w_pool(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_W_POOL_DATA_0) then
                    int_w_pool(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_w_pool(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_w_pool(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_W_POOL_DATA_1) then
                    int_w_pool(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_w_pool(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_bias_pool(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BIAS_POOL_DATA_0) then
                    int_bias_pool(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_bias_pool(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_bias_pool(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BIAS_POOL_DATA_1) then
                    int_bias_pool(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_bias_pool(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_shift_pool(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SHIFT_POOL_DATA_0) then
                    int_shift_pool(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_shift_pool(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_shift_pool(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SHIFT_POOL_DATA_1) then
                    int_shift_pool(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_shift_pool(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_a(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_A_DATA_0) then
                    int_scratch_a(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_a(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_a(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_A_DATA_1) then
                    int_scratch_a(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_a(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_b(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_B_DATA_0) then
                    int_scratch_b(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_b(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_b(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_B_DATA_1) then
                    int_scratch_b(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_b(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_c(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_C_DATA_0) then
                    int_scratch_c(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_c(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_c(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_C_DATA_1) then
                    int_scratch_c(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_c(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_d(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_D_DATA_0) then
                    int_scratch_d(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_d(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_d(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_D_DATA_1) then
                    int_scratch_d(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_d(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_e(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_E_DATA_0) then
                    int_scratch_e(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_e(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_e(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_E_DATA_1) then
                    int_scratch_e(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_e(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_f(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_F_DATA_0) then
                    int_scratch_f(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_f(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_f(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_F_DATA_1) then
                    int_scratch_f(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_f(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spike(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPIKE_DATA_0) then
                    int_scratch_spike(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spike(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spike(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPIKE_DATA_1) then
                    int_scratch_spike(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spike(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_acc(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_ACC_DATA_0) then
                    int_scratch_acc(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_acc(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_acc(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_ACC_DATA_1) then
                    int_scratch_acc(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_acc(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_a(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_A_DATA_0) then
                    int_scratch_spk_a(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_a(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_a(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_A_DATA_1) then
                    int_scratch_spk_a(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_a(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_b(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_B_DATA_0) then
                    int_scratch_spk_b(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_b(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_b(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_B_DATA_1) then
                    int_scratch_spk_b(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_b(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_c(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_C_DATA_0) then
                    int_scratch_spk_c(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_c(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_c(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_C_DATA_1) then
                    int_scratch_spk_c(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_c(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_d(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_D_DATA_0) then
                    int_scratch_spk_d(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_d(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_d(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_D_DATA_1) then
                    int_scratch_spk_d(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_d(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_e(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_E_DATA_0) then
                    int_scratch_spk_e(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_e(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_scratch_spk_e(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SCRATCH_SPK_E_DATA_1) then
                    int_scratch_spk_e(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_scratch_spk_e(63 downto 32));
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------

end architecture behave;
